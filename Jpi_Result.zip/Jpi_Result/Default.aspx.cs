﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class _Default : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString);
    private void Connection()
    {
        if (cn.State == ConnectionState.Open)
        {
            cn.Close();
        }

        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["id"] = "";
        Session["uname"] = "";
        Session["type"] = "";
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        int err = 0;
        lblEpassword.Text = "";
        lblEname.Text = "";
        lblmessage.Text = "";
        if (txtuname.Text == "")
        {
            err++;
            lblEname.Text = "Username Required";
        }
        if (txtpassword.Text == "")
        {
            err++;
            lblEpassword.Text = "Password Required";
        }
        if (err == 0)
        {
            Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from Admin where uname = @u and pword = @p";
            cmd.Parameters.AddWithValue("@u", txtuname.Text);
            cmd.Parameters.AddWithValue("@p", txtpassword.Text);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Session["uname"] = dr["uname"].ToString();
                Session["type"] = dr["type"].ToString();
                if (Session["type"].ToString() == "S")
                {
                    Server.Transfer("Userpanel.aspx");   
                }
                else if (Session["type"].ToString() == "A")
                {
                    Server.Transfer("Info.aspx");
                }
            }
            lblmessage.Text = "You are Not Authorised!";
            lblmessage.ForeColor = System.Drawing.Color.Red;

        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblEpassword.Text = "";
        lblEname.Text = "";
        lblmessage.Text = "";
        txtpassword.Text = "";
        txtuname.Text = "";
    }
}
