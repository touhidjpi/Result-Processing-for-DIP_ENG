﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Cmt2ndDs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbldate.Text = System.DateTime.Now.ToString("Y");
        SqlDataSource1.SelectCommand = @"SELECT [department], [name], [roll], [reg], [semester], [held], [year], [total5722], [lg5722], [gp5722], [total5812], [lg5812], [gp5812], [total5912], [lg5912], [gp5912], [total5921], [lg5921], [gp5921], [total6621], [lg6621], [gp6621], [total5711], [lg5711], [gp5711], [total6821], [lg6821], [gp6821], [total7011], [lg7011], [gp7011], [totalgp], [result] 
        FROM [VwCmt2nd] where (roll like '%" + Session["id"].ToString() + "%') ";
        DetailsView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}
