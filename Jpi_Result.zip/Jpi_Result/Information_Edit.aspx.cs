﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class Information_Edit : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString);
    private void Connection()
    {
        if (cn.State == ConnectionState.Open)
        {
            cn.Close();
        }

        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"].ToString() == "")
        {
            Server.Transfer("Default.aspx");
        }
        Session["id"] = "";
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
        int err = 0;
        if (txtRoll.Text == "")
        {
            err++;
            lblmessage.Text = "Roll Number Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
        }
        if (err == 0)
        {
            Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from studentinfo where roll = @r";
            cmd.Parameters.AddWithValue("@r", txtRoll.Text);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Session["id"] = dr["roll"].ToString();
                Server.Transfer("InfoEdit.aspx");
            }
            lblmessage.Text = "Database Not Found The Roll Number!";
            lblmessage.ForeColor = System.Drawing.Color.Red;

        }
    }
    protected void Btnreset_Click(object sender, EventArgs e)
    {
        lblmessage.Text = "";
        txtRoll.Text = "";
        txtRoll.Focus();
    }
}
