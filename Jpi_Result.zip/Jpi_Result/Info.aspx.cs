﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class Info : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString);
    private void Connection()
    {
        if (cn.State == ConnectionState.Open)
        {
            cn.Close();
        }

        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"].ToString() == "")
        {
            Server.Transfer("Default.aspx");
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        int err = 0;
        string ext = "";
        if (txtroll.Text == "")
        {
            err++;
            lblmessage.Text = "Roll Number Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtroll.Focus();
        }
        else if (txtname.Text == "")
        {
            err++;
            lblmessage.Text = "Name Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtname.Focus();
        }
        else if (txtReg.Text == "")
        {
            err++;
            lblmessage.Text = "Registration Number Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtReg.Focus();
        }
        else if (ddldept.SelectedIndex==0)
        {
            err++;
            lblmessage.Text = "Department Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddldept.Focus();
        }
        else if (ddlSem.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Semester Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddlSem.Focus();
        }
        else if (ddlShift.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Shift Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddlShift.Focus();
        }
        else if (ddlGender.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Gender Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddlGender.Focus();
        }
        else if (txtfname.Text =="")
        {
            err++;
            lblmessage.Text = "Father Name Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtfname.Focus();
        }
        else if (txtVill.Text == "")
        {
            err++;
            lblmessage.Text = "Village Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtVill.Focus();
        }
        else if (txtPost.Text == "")
        {
            err++;
            lblmessage.Text = "Post Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtPost.Focus();
        }
        else if (txtUpazila.Text == "")
        {
            err++;
            lblmessage.Text = "Upazila Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtUpazila.Focus();
        }
        else if (txtDistrict.Text == "")
        {
            err++;
            lblmessage.Text = "District Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtDistrict.Focus();
        }
        else if (txtMobile.Text == "")
        {
            err++;
            lblmessage.Text = "Mobile Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtMobile.Focus();
        }
        else if (txtGuardian.Text == "")
        {
            err++;
            lblmessage.Text = "Guardian Mobile Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtGuardian.Focus();
        }
        else if (flbPhoto.FileName != "")
        {
            string n = flbPhoto.FileName.ToLower();
            if (n.EndsWith(".jpg"))
            {
                ext = ".jpg";
            }
            else if (n.EndsWith(".gif"))
            {
                ext = ".gif";
            }
            else if (n.EndsWith(".png"))
            {
                ext = ".png";
            }
            else if (n.EndsWith(".bmp"))
            {
                ext = ".bmp";
            }
            else
            {
                err++;
                lblmessage.Text = "Invalid Image Format";
                lblmessage.ForeColor = System.Drawing.Color.Red;
                flbPhoto.Focus();
            }
        }
        if (txtroll.Text != "")
        {
            Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from studentinfo where roll = @r";
            cmd.Parameters.AddWithValue("@r", txtroll.Text);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                err++;
                lblmessage.Text = "This Roll Number Already Taken!";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
        }
        if (err == 0)
        {
            Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = @"insert into studentinfo (roll,name,department,semester,shift,fname,village,post,upazila,district,mobile,fmobile,blood,reg,Sex,imagepath) 
                values(@roll,@name,@department,@semester,@shift,@fname,@village,@post,@upazila,@district,@mobile,@fmobile,@blood,@reg,@Sex,@imagepath)";
            cmd.Parameters.AddWithValue("@roll", txtroll.Text);
            cmd.Parameters.AddWithValue("@name", txtname.Text);
            cmd.Parameters.AddWithValue("@department", ddldept.SelectedValue);
            cmd.Parameters.AddWithValue("@semester", ddlSem.SelectedValue);
            cmd.Parameters.AddWithValue("@shift", ddlShift.SelectedValue);
            cmd.Parameters.AddWithValue("@fname", txtfname.Text);
            cmd.Parameters.AddWithValue("@village", txtVill.Text);
            cmd.Parameters.AddWithValue("@post", txtPost.Text);
            cmd.Parameters.AddWithValue("@upazila", txtUpazila.Text);
            cmd.Parameters.AddWithValue("@district", txtDistrict.Text);
            cmd.Parameters.AddWithValue("@mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@fmobile", txtGuardian.Text);
            cmd.Parameters.AddWithValue("@blood", txtBlood.Text);
            cmd.Parameters.AddWithValue("@reg", txtReg.Text);
            cmd.Parameters.AddWithValue("@Sex", ddlGender.SelectedValue);
            cmd.Parameters.AddWithValue("@imagepath", ext);
            try
            {
                cmd.ExecuteNonQuery();
                flbPhoto.SaveAs(Server.MapPath("StudentsImage/" + txtroll.Text + ext));
                lblmessage.Text = "Saved Successfully";
                lblmessage.ForeColor = System.Drawing.Color.Green;
                txtroll.Text = "";
                ddldept.SelectedIndex = 0;
                ddlSem.SelectedIndex = 0;
                ddlShift.SelectedIndex = 0;
                ddlGender.SelectedIndex = 0;
                txtname.Text = "";
                txtfname.Text = "";
                txtVill.Text = "";
                txtPost.Text = "";
                txtUpazila.Text = "";
                txtDistrict.Text = "";
                txtMobile.Text = "";
                txtGuardian.Text = "";
                txtReg.Text = "";
                txtBlood.Text = "";
                txtroll.Focus();

            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

        }
       
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtroll.Text = "";
        ddldept.SelectedIndex = 0;
        ddlSem.SelectedIndex = 0;
        ddlShift.SelectedIndex = 0;
        ddlGender.SelectedIndex = 0;
        txtname.Text = "";
        txtfname.Text = "";
        txtVill.Text = "";
        txtPost.Text = "";
        txtUpazila.Text = "";
        txtDistrict.Text = "";
        txtMobile.Text = "";
        txtGuardian.Text = "";
        txtReg.Text = "";
        txtBlood.Text = "";
        txtroll.Focus();
        lblmessage.Text = "";
    }
}
