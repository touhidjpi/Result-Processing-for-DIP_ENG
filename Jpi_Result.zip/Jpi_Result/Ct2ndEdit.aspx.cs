﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class Ct2nd : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString);
    private void Connection()
    {
        if (cn.State == ConnectionState.Open)
        {
            cn.Close();
        }

        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"].ToString() == "")
        {
            Server.Transfer("Default.aspx");
        }
        string id = Session["id"].ToString();
        if (!IsPostBack)
        {
            if (id != "" && id != null)
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = @"select Ct2nd.* from 
                Ct2nd where Ct2nd.roll=@roll";
                cmd.Parameters.AddWithValue("@roll", id);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txtRoll.Text = dr["roll"].ToString();
                    ddltype.SelectedValue = dr["type"].ToString();
                    ddlMonth.SelectedValue = dr["held"].ToString();
                    ddlYear.SelectedValue = dr["year"].ToString();

                    Tc5722.Text = dr["tc5722"].ToString();
                    Tf5722.Text = dr["tf5722"].ToString();
                    Pc5722.Text = dr["pc5722"].ToString();
                    Tc1012.Text = dr["tc1012"].ToString();
                    Tf1012.Text = dr["tf1012"].ToString();
                    Pc1012.Text = dr["pc1012"].ToString();
                    Pf1012.Text = dr["pf1012"].ToString();
                    Tc5912.Text = dr["tc5912"].ToString();
                    Tf5912.Text = dr["tf5912"].ToString();
                    Pc5912.Text = dr["pc5912"].ToString();
                    Pf5912.Text = dr["pf5912"].ToString();
                    Tc5921.Text = dr["tc5921"].ToString();
                    Tf5921.Text = dr["tf5921"].ToString();
                    Pc5921.Text = dr["pc5921"].ToString();
                    Pc6621.Text = dr["pc6621"].ToString();
                    Pf6621.Text = dr["pf6621"].ToString();
                    Tc5711.Text = dr["tc5711"].ToString();
                    Tf5711.Text = dr["tf5711"].ToString();
                    Pc5711.Text = dr["pc5711"].ToString();
                    Pf6711.Text = dr["pf6711"].ToString();
                    Tc6821.Text = dr["tc6821"].ToString();
                    Tf6821.Text = dr["tf6821"].ToString();

                    txttotalFail.Text = dr["totalfail"].ToString();
                    txtFailedCode.Text = dr["failcode"].ToString();
                    txtTotalgp.Text = dr["totalgp"].ToString();
                    txtGPA.Text = dr["gpa"].ToString();
                    txtResult.Text = dr["result"].ToString();

                    Total5722.Text = dr["total5722"].ToString();
                    Total5812.Text = dr["total5812"].ToString();
                    Total5912.Text = dr["total5912"].ToString();
                    Total5921.Text = dr["total5921"].ToString();
                    Total6621.Text = dr["total6621"].ToString();
                    Total5711.Text = dr["total5711"].ToString();
                    Total6821.Text = dr["total6821"].ToString();
                    Lg5711.Text = dr["lg5711"].ToString();
                    Lg5722.Text = dr["lg5722"].ToString();
                    Lg5812.Text = dr["lg5812"].ToString();
                    Lg5912.Text = dr["lg5912"].ToString();
                    Lg5921.Text = dr["lg5921"].ToString();
                    Lg6621.Text = dr["lg6621"].ToString();
                    Lg6821.Text = dr["lg6821"].ToString();
                    Gp5711.Text = dr["gp5711"].ToString();
                    Gp5722.Text = dr["gp5722"].ToString();
                    Gp5812.Text = dr["gp5812"].ToString();
                    Gp5912.Text = dr["gp5912"].ToString();
                    Gp5921.Text = dr["gp5921"].ToString();
                    Gp6621.Text = dr["gp6621"].ToString();
                    Gp6821.Text = dr["gp6821"].ToString();

                }
            }
        }
    }
    protected void Tc5722_TextChanged(object sender, EventArgs e)
    {

        int Total_5722;
        int tctxt = Convert.ToInt32(Tc5722.Text);
        int tftxt = Convert.ToInt32(Tf5722.Text);
        int pctxt = Convert.ToInt32(Pc5722.Text);

        if (tctxt >= 0 && tctxt <= 20)
        {
            int tc_tf = (tctxt + tftxt);

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5722 = (tc_tf + pctxt);
            }
            else
            {
                Total_5722 = 0;
            }

            //-----5722--------//

            if (Total_5722 >= 120)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "4.00";
                Lg5722.Text = "A+";
            }
            else if (Total_5722 >= 112.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.75";
                Lg5722.Text = "A";
            }
            else if (Total_5722 >= 105)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.50";
                Lg5722.Text = "A-";
            }
            else if (Total_5722 >= 97.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.25";
                Lg5722.Text = "B+";
            }
            else if (Total_5722 >= 90)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.00";
                Lg5722.Text = "B";
            }
            else if (Total_5722 >= 82.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.75";
                Lg5722.Text = "B-";
            }
            else if (Total_5722 >= 75)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.50";
                Lg5722.Text = "C+";
            }
            else if (Total_5722 >= 67.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.25";
                Lg5722.Text = "C";
            }
            else if (Total_5722 >= 60)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.00";
                Lg5722.Text = "D";
            }
            else
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "0.00";
                Lg5722.Text = "F";
            }
            Tf5722.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=20 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5722.Focus();
        }

    }
    protected void Tf5722_TextChanged(object sender, EventArgs e)
    {
        int Total_5722;
        int tctxt = Convert.ToInt32(Tc5722.Text);
        int tftxt = Convert.ToInt32(Tf5722.Text);
        int pctxt = Convert.ToInt32(Pc5722.Text);
        if (tftxt >= 0 && tftxt <= 80)
        {
            int tc_tf = (tctxt + tftxt);

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5722 = (tc_tf + pctxt);
            }
            else
            {
                Total_5722 = 0;
            }

            //-----5722--------//

            if (Total_5722 >= 120)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "4.00";
                Lg5722.Text = "A+";
            }
            else if (Total_5722 >= 112.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.75";
                Lg5722.Text = "A";
            }
            else if (Total_5722 >= 105)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.50";
                Lg5722.Text = "A-";
            }
            else if (Total_5722 >= 97.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.25";
                Lg5722.Text = "B+";
            }
            else if (Total_5722 >= 90)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.00";
                Lg5722.Text = "B";
            }
            else if (Total_5722 >= 82.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.75";
                Lg5722.Text = "B-";
            }
            else if (Total_5722 >= 75)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.50";
                Lg5722.Text = "C+";
            }
            else if (Total_5722 >= 67.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.25";
                Lg5722.Text = "C";
            }
            else if (Total_5722 >= 60)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.00";
                Lg5722.Text = "D";
            }
            else
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "0.00";
                Lg5722.Text = "F";
            }
            Pc5722.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=80 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5722.Focus();
        }

    }
    protected void Pc5722_TextChanged(object sender, EventArgs e)
    {
        int Total_5722;
        int tctxt = Convert.ToInt32(Tc5722.Text);
        int tftxt = Convert.ToInt32(Tf5722.Text);
        int pctxt = Convert.ToInt32(Pc5722.Text);
        int tc_tf = (tctxt + tftxt);

        if (pctxt >= 0 && pctxt <= 50)
        {

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5722 = (tc_tf + pctxt);
            }
            else
            {
                Total_5722 = 0;
            }

            //-----5722--------//

            if (Total_5722 >= 120)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "4.00";
                Lg5722.Text = "A+";
            }
            else if (Total_5722 >= 112.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.75";
                Lg5722.Text = "A";
            }
            else if (Total_5722 >= 105)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.50";
                Lg5722.Text = "A-";
            }
            else if (Total_5722 >= 97.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.25";
                Lg5722.Text = "B+";
            }
            else if (Total_5722 >= 90)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.00";
                Lg5722.Text = "B";
            }
            else if (Total_5722 >= 82.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.75";
                Lg5722.Text = "B-";
            }
            else if (Total_5722 >= 75)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.50";
                Lg5722.Text = "C+";
            }
            else if (Total_5722 >= 67.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.25";
                Lg5722.Text = "C";
            }
            else if (Total_5722 >= 60)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.00";
                Lg5722.Text = "D";
            }
            else
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "0.00";
                Lg5722.Text = "F";
            }
            Tc1012.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5722.Focus();
        }
    }
    protected void Tc1012_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc1012.Text);
        int tftxt = Convert.ToInt32(Tf1012.Text);
        int pctxt = Convert.ToInt32(Pc1012.Text);
        int pftxt = Convert.ToInt32(Pf1012.Text);
        int tc_tf = (tctxt + tftxt);

        if (tctxt >= 0 && tctxt <= 20)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "4.00";
                Lg5812.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.75";
                Lg5812.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.50";
                Lg5812.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.25";
                Lg5812.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.00";
                Lg5812.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.75";
                Lg5812.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.50";
                Lg5812.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.25";
                Lg5812.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.00";
                Lg5812.Text = "D";
            }
            else
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "0.00";
                Lg5812.Text = "F";
            }
            Tf1012.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=20 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc1012.Focus();
        }
    }
    protected void Tf1012_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc1012.Text);
        int tftxt = Convert.ToInt32(Tf1012.Text);
        int pctxt = Convert.ToInt32(Pc1012.Text);
        int pftxt = Convert.ToInt32(Pf1012.Text);
        int tc_tf = (tctxt + tftxt);

        if (tftxt >= 0 && tftxt <= 80)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "4.00";
                Lg5812.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.75";
                Lg5812.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.50";
                Lg5812.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.25";
                Lg5812.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.00";
                Lg5812.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.75";
                Lg5812.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.50";
                Lg5812.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.25";
                Lg5812.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.00";
                Lg5812.Text = "D";
            }
            else
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "0.00";
                Lg5812.Text = "F";
            }
            Pc1012.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=80 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf1012.Focus();
        }
    }
    protected void Pc1012_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc1012.Text);
        int tftxt = Convert.ToInt32(Tf1012.Text);
        int pctxt = Convert.ToInt32(Pc1012.Text);
        int pftxt = Convert.ToInt32(Pf1012.Text);
        int tc_tf = (tctxt + tftxt);


        if (pctxt >= 0 && pctxt <= 25)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "4.00";
                Lg5812.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.75";
                Lg5812.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.50";
                Lg5812.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.25";
                Lg5812.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.00";
                Lg5812.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.75";
                Lg5812.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.50";
                Lg5812.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.25";
                Lg5812.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.00";
                Lg5812.Text = "D";
            }
            else
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "0.00";
                Lg5812.Text = "F";
            }
            Pf1012.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc1012.Focus();
        }

    }
    protected void Pf1012_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc1012.Text);
        int tftxt = Convert.ToInt32(Tf1012.Text);
        int pctxt = Convert.ToInt32(Pc1012.Text);
        int pftxt = Convert.ToInt32(Pf1012.Text);
        int tc_tf = (tctxt + tftxt);


        if (pftxt >= 0 && pftxt <= 25)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "4.00";
                Lg5812.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.75";
                Lg5812.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.50";
                Lg5812.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.25";
                Lg5812.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "3.00";
                Lg5812.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.75";
                Lg5812.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.50";
                Lg5812.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.25";
                Lg5812.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "2.00";
                Lg5812.Text = "D";
            }
            else
            {
                Total5812.Text = Total_5711.ToString();
                Gp5812.Text = "0.00";
                Lg5812.Text = "F";
            }
            Tc5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf1012.Focus();
        }
    }
    protected void Tc5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);



        if (tctxt >= 0 && tctxt <= 30)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Tf5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=30 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5912.Focus();
        }
    }
    protected void Tf5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);

        if (tftxt >= 0 && tftxt <= 120)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Pc5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=120 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5912.Focus();
        }
    }
    protected void Pc5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);

        if (pctxt >= 0 && pctxt <= 25)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Pf5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5912.Focus();
        }
    }
    protected void Pf5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);

        if (pftxt >= 0 && pftxt <= 25)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Tc5921.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf5912.Focus();
        }
    }
    protected void Tc5921_TextChanged(object sender, EventArgs e)
    {
        int Total_5921;
        int tctxt = Convert.ToInt32(Tc5921.Text);
        int tftxt = Convert.ToInt32(Tf5921.Text);
        int pctxt = Convert.ToInt32(Pc5921.Text);
        int tc_tf = (tctxt + tftxt);

        if (tctxt >= 0 && tctxt <= 30)
        {

            if (tc_tf >= 60 && pctxt >= 20)
            {
                Total_5921 = (tc_tf + pctxt);
            }
            else
            {
                Total_5921 = 0;
            }

            //-----5921--------//

            if (Total_5921 >= 160)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "4.00";
                Lg5921.Text = "A+";
            }
            else if (Total_5921 >= 150)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.75";
                Lg5921.Text = "A";
            }
            else if (Total_5921 >= 140)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.50";
                Lg5921.Text = "A-";
            }
            else if (Total_5921 >= 130)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.25";
                Lg5921.Text = "B+";
            }
            else if (Total_5921 >= 120)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.00";
                Lg5921.Text = "B";
            }
            else if (Total_5921 >= 110)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.75";
                Lg5921.Text = "B-";
            }
            else if (Total_5921 >= 100)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.50";
                Lg5921.Text = "C+";
            }
            else if (Total_5921 >= 90)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.25";
                Lg5921.Text = "C";
            }
            else if (Total_5921 >= 80)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.00";
                Lg5921.Text = "D";
            }
            else
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "0.00";
                Lg5921.Text = "F";
            }
            Tf5921.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=30 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5921.Focus();
        }
    }
    protected void Tf5921_TextChanged(object sender, EventArgs e)
    {
        int Total_5921;
        int tctxt = Convert.ToInt32(Tc5921.Text);
        int tftxt = Convert.ToInt32(Tf5921.Text);
        int pctxt = Convert.ToInt32(Pc5921.Text);
        int tc_tf = (tctxt + tftxt);



        if (tftxt >= 0 && tftxt <= 120)
        {

            if (tc_tf >= 60 && pctxt >= 20)
            {
                Total_5921 = (tc_tf + pctxt);
            }
            else
            {
                Total_5921 = 0;
            }

            //-----5921--------//

            if (Total_5921 >= 160)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "4.00";
                Lg5921.Text = "A+";
            }
            else if (Total_5921 >= 150)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.75";
                Lg5921.Text = "A";
            }
            else if (Total_5921 >= 140)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.50";
                Lg5921.Text = "A-";
            }
            else if (Total_5921 >= 130)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.25";
                Lg5921.Text = "B+";
            }
            else if (Total_5921 >= 120)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.00";
                Lg5921.Text = "B";
            }
            else if (Total_5921 >= 110)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.75";
                Lg5921.Text = "B-";
            }
            else if (Total_5921 >= 100)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.50";
                Lg5921.Text = "C+";
            }
            else if (Total_5921 >= 90)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.25";
                Lg5921.Text = "C";
            }
            else if (Total_5921 >= 80)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.00";
                Lg5921.Text = "D";
            }
            else
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "0.00";
                Lg5921.Text = "F";
            }
            Pc5921.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=120 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5921.Focus();
        }
    }
    protected void Pc5921_TextChanged(object sender, EventArgs e)
    {
        int Total_5921;
        int tctxt = Convert.ToInt32(Tc5921.Text);
        int tftxt = Convert.ToInt32(Tf5921.Text);
        int pctxt = Convert.ToInt32(Pc5921.Text);
        int tc_tf = (tctxt + tftxt);


        if (pctxt >= 0 && pctxt <= 50)
        {

            if (tc_tf >= 60 && pctxt >= 20)
            {
                Total_5921 = (tc_tf + pctxt);
            }
            else
            {
                Total_5921 = 0;
            }

            //-----5921--------//

            if (Total_5921 >= 160)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "4.00";
                Lg5921.Text = "A+";
            }
            else if (Total_5921 >= 150)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.75";
                Lg5921.Text = "A";
            }
            else if (Total_5921 >= 140)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.50";
                Lg5921.Text = "A-";
            }
            else if (Total_5921 >= 130)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.25";
                Lg5921.Text = "B+";
            }
            else if (Total_5921 >= 120)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.00";
                Lg5921.Text = "B";
            }
            else if (Total_5921 >= 110)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.75";
                Lg5921.Text = "B-";
            }
            else if (Total_5921 >= 100)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.50";
                Lg5921.Text = "C+";
            }
            else if (Total_5921 >= 90)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.25";
                Lg5921.Text = "C";
            }
            else if (Total_5921 >= 80)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.00";
                Lg5921.Text = "D";
            }
            else
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "0.00";
                Lg5921.Text = "F";
            }
            Pc6621.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5921.Focus();
        }



    }
    protected void Pc6621_TextChanged(object sender, EventArgs e)
    {
        int Total_6621;
        int pctxt = Convert.ToInt32(Pc6621.Text);
        int pftxt = Convert.ToInt32(Pf6621.Text);

        if (pctxt >= 0 && pctxt <= 50)
        {

            if (pctxt >= 20 && pftxt >= 20)
            {
                Total_6621 = (pctxt + pftxt);
            }
            else
            {
                Total_6621 = 0;
            }

            //-----6621--------//

            if (Total_6621 >= 80)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "4.00";
                Lg6621.Text = "A+";
            }
            else if (Total_6621 >= 75)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.75";
                Lg6621.Text = "A";
            }
            else if (Total_6621 >= 70)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.50";
                Lg6621.Text = "A-";
            }
            else if (Total_6621 >= 65)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.25";
                Lg6621.Text = "B+";
            }
            else if (Total_6621 >= 60)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.00";
                Lg6621.Text = "B";
            }
            else if (Total_6621 >= 55)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.75";
                Lg6621.Text = "B-";
            }
            else if (Total_6621 >= 50)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.50";
                Lg6621.Text = "C+";
            }
            else if (Total_6621 >= 45)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.25";
                Lg6621.Text = "C";
            }
            else if (Total_6621 >= 40)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.00";
                Lg6621.Text = "D";
            }
            else
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "0.00";
                Lg6621.Text = "F";
            }
            Pf6621.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc6621.Focus();
        }
    }
    protected void Pf6621_TextChanged(object sender, EventArgs e)
    {
        int Total_6621;
        int pctxt = Convert.ToInt32(Pc6621.Text);
        int pftxt = Convert.ToInt32(Pf6621.Text);


        if (pftxt >= 0 && pftxt <= 50)
        {

            if (pctxt >= 20 && pftxt >= 20)
            {
                Total_6621 = (pctxt + pftxt);
            }
            else
            {
                Total_6621 = 0;
            }

            //-----6621--------//

            if (Total_6621 >= 80)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "4.00";
                Lg6621.Text = "A+";
            }
            else if (Total_6621 >= 75)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.75";
                Lg6621.Text = "A";
            }
            else if (Total_6621 >= 70)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.50";
                Lg6621.Text = "A-";
            }
            else if (Total_6621 >= 65)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.25";
                Lg6621.Text = "B+";
            }
            else if (Total_6621 >= 60)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.00";
                Lg6621.Text = "B";
            }
            else if (Total_6621 >= 55)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.75";
                Lg6621.Text = "B-";
            }
            else if (Total_6621 >= 50)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.50";
                Lg6621.Text = "C+";
            }
            else if (Total_6621 >= 45)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.25";
                Lg6621.Text = "C";
            }
            else if (Total_6621 >= 40)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.00";
                Lg6621.Text = "D";
            }
            else
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "0.00";
                Lg6621.Text = "F";
            }
            Tc5711.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf6621.Focus();
        }

    }
    protected void Tc5711_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc5711.Text);
        int tftxt = Convert.ToInt32(Tf5711.Text);
        int pctxt = Convert.ToInt32(Pc5711.Text);
        int pftxt = Convert.ToInt32(Pf6711.Text);
        int tc_tf = (tctxt + tftxt);

        if (tctxt >= 0 && tctxt <= 20)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "4.00";
                Lg5711.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.75";
                Lg5711.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.50";
                Lg5711.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.25";
                Lg5711.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.00";
                Lg5711.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.75";
                Lg5711.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.50";
                Lg5711.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.25";
                Lg5711.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.00";
                Lg5711.Text = "D";
            }
            else
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "0.00";
                Lg5711.Text = "F";
            }
            Tf5711.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=20 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5711.Focus();
        }
    }
    protected void Tf5711_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc5711.Text);
        int tftxt = Convert.ToInt32(Tf5711.Text);
        int pctxt = Convert.ToInt32(Pc5711.Text);
        int pftxt = Convert.ToInt32(Pf6711.Text);
        int tc_tf = (tctxt + tftxt);

        if (tftxt >= 0 && tftxt <= 80)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "4.00";
                Lg5711.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.75";
                Lg5711.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.50";
                Lg5711.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.25";
                Lg5711.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.00";
                Lg5711.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.75";
                Lg5711.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.50";
                Lg5711.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.25";
                Lg5711.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.00";
                Lg5711.Text = "D";
            }
            else
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "0.00";
                Lg5711.Text = "F";
            }
            Pc5711.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=80 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5711.Focus();
        }
    }
    protected void Pc5711_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc5711.Text);
        int tftxt = Convert.ToInt32(Tf5711.Text);
        int pctxt = Convert.ToInt32(Pc5711.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);


        if (pctxt >= 0 && pctxt <= 25)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "4.00";
                Lg5711.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.75";
                Lg5711.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.50";
                Lg5711.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.25";
                Lg5711.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.00";
                Lg5711.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.75";
                Lg5711.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.50";
                Lg5711.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.25";
                Lg5711.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.00";
                Lg5711.Text = "D";
            }
            else
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "0.00";
                Lg5711.Text = "F";
            }
            Pf6711.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5711.Focus();
        }

    }
    protected void Pf6711_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc5711.Text);
        int tftxt = Convert.ToInt32(Tf5711.Text);
        int pctxt = Convert.ToInt32(Pc5711.Text);
        int pftxt = Convert.ToInt32(Pf6711.Text);
        int tc_tf = (tctxt + tftxt);


        if (pftxt >= 0 && pftxt <= 25)
        {

            if (tc_tf >= 40 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5711 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "4.00";
                Lg5711.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.75";
                Lg5711.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.50";
                Lg5711.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.25";
                Lg5711.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.00";
                Lg5711.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.75";
                Lg5711.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.50";
                Lg5711.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.25";
                Lg5711.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.00";
                Lg5711.Text = "D";
            }
            else
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "0.00";
                Lg5711.Text = "F";
            }
            Tc6821.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf6711.Focus();
        }
    }
    protected void Tc6821_TextChanged(object sender, EventArgs e)
    {
        int Total_6821;
        int tctxt = Convert.ToInt32(Tc6821.Text);
        int tftxt = Convert.ToInt32(Tf6821.Text);
        int tc_tf = (tctxt + tftxt);

        if (tctxt >= 0 && tctxt <= 20)
        {

            if (tc_tf >= 40)
            {
                Total_6821 = tc_tf;
            }
            else
            {
                Total_6821 = 0;
            }

            //-----6821--------//

            if (Total_6821 >= 80)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "4.00";
                Lg6821.Text = "A+";
            }
            else if (Total_6821 >= 75)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.75";
                Lg6821.Text = "A";
            }
            else if (Total_6821 >= 70)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.50";
                Lg6821.Text = "A-";
            }
            else if (Total_6821 >= 65)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.25";
                Lg6821.Text = "B+";
            }
            else if (Total_6821 >= 60)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.00";
                Lg6821.Text = "B";
            }
            else if (Total_6821 >= 55)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.75";
                Lg6821.Text = "B-";
            }
            else if (Total_6821 >= 50)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.50";
                Lg6821.Text = "C+";
            }
            else if (Total_6821 >= 45)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.25";
                Lg6821.Text = "C";
            }
            else if (Total_6821 >= 40)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.00";
                Lg6821.Text = "D";
            }
            else
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "0.00";
                Lg6821.Text = "F";
            }
            Tf6821.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=20 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc6821.Focus();
        }

    }
    protected void Tf6821_TextChanged(object sender, EventArgs e)
    {
        int Total_6821;
        int tctxt = Convert.ToInt32(Tc6821.Text);
        int tftxt = Convert.ToInt32(Tf6821.Text);
        int tc_tf = (tctxt + tftxt);



        if (tftxt >= 0 && tftxt <= 80)
        {

            if (tc_tf >= 40)
            {
                Total_6821 = tc_tf;
            }
            else
            {
                Total_6821 = 0;
            }

            //-----6821--------//

            if (Total_6821 >= 80)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "4.00";
                Lg6821.Text = "A+";
            }
            else if (Total_6821 >= 75)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.75";
                Lg6821.Text = "A";
            }
            else if (Total_6821 >= 70)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.50";
                Lg6821.Text = "A-";
            }
            else if (Total_6821 >= 65)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.25";
                Lg6821.Text = "B+";
            }
            else if (Total_6821 >= 60)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.00";
                Lg6821.Text = "B";
            }
            else if (Total_6821 >= 55)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.75";
                Lg6821.Text = "B-";
            }
            else if (Total_6821 >= 50)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.50";
                Lg6821.Text = "C+";
            }
            else if (Total_6821 >= 45)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.25";
                Lg6821.Text = "C";
            }
            else if (Total_6821 >= 40)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.00";
                Lg6821.Text = "D";
            }
            else
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "0.00";
                Lg6821.Text = "F";
            }
            Btnsave.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=80 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf6821.Focus();
        }
    }
    protected void Btnsave_Click(object sender, EventArgs e)
    {
        ////-----Valition Code---------/////

        int err = 0;
        int txtTc5722 = Convert.ToInt32(Tc5722.Text);
        int txtTf5722 = Convert.ToInt32(Tf5722.Text);
        int txtPc5722 = Convert.ToInt32(Pc5722.Text);
        int txtTc1012 = Convert.ToInt32(Tc1012.Text);
        int txtTf1012 = Convert.ToInt32(Tf1012.Text);
        int txtPc1012 = Convert.ToInt32(Pc1012.Text);
        int txtPf1012 = Convert.ToInt32(Pf1012.Text);
        int txtTc5912 = Convert.ToInt32(Tc5912.Text);
        int txtTf5912 = Convert.ToInt32(Tf5912.Text);
        int txtPc5912 = Convert.ToInt32(Pc5912.Text);
        int txtPf5912 = Convert.ToInt32(Pf5912.Text);
        int txtTc5921 = Convert.ToInt32(Tc5921.Text);
        int txtTf5921 = Convert.ToInt32(Tf5921.Text);
        int txtPc5921 = Convert.ToInt32(Pc5921.Text);
        int txtPc6621 = Convert.ToInt32(Pc6621.Text);
        int txtPf6621 = Convert.ToInt32(Pf6621.Text);
        int txtTc5711 = Convert.ToInt32(Tc5711.Text);
        int txtTf5711 = Convert.ToInt32(Tf5711.Text);
        int txtPc5711 = Convert.ToInt32(Pc5711.Text);
        int txtPf6711 = Convert.ToInt32(Pf6711.Text);
        int txtTc6821 = Convert.ToInt32(Tc6821.Text);
        int txtTf6821 = Convert.ToInt32(Tf6821.Text);

        if (txtRoll.Text == "")
        {
            err++;
            lblmessage.Text = "Roll Number Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtRoll.Focus();
        }
        else if (ddltype.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Type Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddltype.Focus();
        }
        else if (ddlMonth.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Month Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddlMonth.Focus();
        }
        else if (ddlYear.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Year Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddlYear.Focus();
        }
        else if (txtTc5722 > 20)
        {
            err++;
            lblmessage.Text = "Required Number <=20";
            Tc5722.Focus();
        }
        else if (txtTf5722 > 80)
        {
            err++;
            lblmessage.Text = "Required Number <=80";
            Tf5722.Focus();
        }
        else if (txtPc5722 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc5722.Focus();
        }
        else if (txtTc1012 > 20)
        {
            err++;
            lblmessage.Text = "Required Number <=20";
            Tc1012.Focus();
        }
        else if (txtTf1012 > 80)
        {
            err++;
            lblmessage.Text = "Required Number <=80";
            Tf1012.Focus();
        }
        else if (txtPc1012 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pc1012.Focus();
        }
        else if (txtPf1012 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pf1012.Focus();
        }
        else if (txtTc5912 > 30)
        {
            err++;
            lblmessage.Text = "Required Number <=30";
            Tc5912.Focus();
        }
        else if (txtTf5912 > 120)
        {
            err++;
            lblmessage.Text = "Required Number <=120";
            Tf5912.Focus();
        }
        else if (txtPc5912 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pc5912.Focus();
        }
        else if (txtPf5912 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pf5912.Focus();
        }
        else if (txtTc5921 > 30)
        {
            err++;
            lblmessage.Text = "Required Number <=30";
            Tc5921.Focus();
        }
        else if (txtTf5921 > 120)
        {
            err++;
            lblmessage.Text = "Required Number <=120";
            Tf5921.Focus();
        }
        else if (txtPc5921 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc5921.Focus();
        }
        else if (txtPc6621 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc6621.Focus();
        }
        else if (txtPf6621 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pf6621.Focus();
        }
        else if (txtTc5711 > 20)
        {
            err++;
            lblmessage.Text = "Required Number <=20";
            Tc5711.Focus();
        }
        else if (txtTf5711 > 80)
        {
            err++;
            lblmessage.Text = "Required Number <=80";
            Tf5711.Focus();
        }
        else if (txtPc5711 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pc5711.Focus();
        }
        else if (txtPf6711 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pf6711.Focus();
        }
        else if (txtTc6821 > 20)
        {
            err++;
            lblmessage.Text = "Required Number <=20";
            Tc6821.Focus();
        }
        else if (txtTf6821 > 80)
        {
            err++;
            lblmessage.Text = "Required Number <=80";
            Tf6821.Focus();
        }
        else if (Total5722.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5722.BorderColor = System.Drawing.Color.Red;
            Tf5722.BorderColor = System.Drawing.Color.Red;
            Pc5722.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5722.Focus();
        }
        else if (Total5812.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc1012.BorderColor = System.Drawing.Color.Red;
            Tf1012.BorderColor = System.Drawing.Color.Red;
            Pf1012.BorderColor = System.Drawing.Color.Red;
            Pc1012.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc1012.Focus();
        }
        else if (Total5912.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5912.BorderColor = System.Drawing.Color.Red;
            Tf5912.BorderColor = System.Drawing.Color.Red;
            Pc5912.BorderColor = System.Drawing.Color.Red;
            Pf5912.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5912.Focus();
        }
        else if (Total5921.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5921.BorderColor = System.Drawing.Color.Red;
            Tf5921.BorderColor = System.Drawing.Color.Red;
            Pc5921.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5921.Focus();
        }
        else if (Total6621.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Pf6621.BorderColor = System.Drawing.Color.Red;
            Pc6621.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc6621.Focus();
        }
        else if (Total5711.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5711.BorderColor = System.Drawing.Color.Red;
            Tf5711.BorderColor = System.Drawing.Color.Red;
            Pc5711.BorderColor = System.Drawing.Color.Red;
            Pf6711.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5711.Focus();
        }
        else if (Total6821.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc6821.BorderColor = System.Drawing.Color.Red;
            Tf6821.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc6821.Focus();
        }
        if (err == 0)
        {

            ///---- Calculation Code----///

            int failed = 0;
            string code = "";
            if (Lg5722.Text == "F")
            {
                failed++;
                code = "5722";
            }
            if (Lg5812.Text == "F")
            {
                failed++;
                code = code + " " + "1012";
            }
            if (Lg5912.Text == "F")
            {
                failed++;
                code = code + " " + "5922";
            }
            if (Lg5921.Text == "F")
            {
                failed++;
                code = code + " " + "5921";
            }
            if (Lg6621.Text == "F")
            {
                failed++;
                code = code + " " + "6621";
            }
            if (Lg5711.Text == "F")
            {
                failed++;
                code = code + " " + "6811";
            }
            if (Lg6821.Text == "F")
            {
                failed++;
                code = code + " " + "5811";
            }
            if (failed > 2)
            {
                txtResult.Text = "Failed";
                txtResult.ForeColor = System.Drawing.Color.Red;
                txttotalFail.Text = failed.ToString();
                txtFailedCode.BorderColor = System.Drawing.Color.Red;
                txtFailedCode.Text = code;
                txtGPA.Text = "F";
                txtTotalgp.Text = "0.00";
            }
            else if (failed > 0 && failed <= 2)
            {
                txtResult.Text = "Reffard";
                txtResult.ForeColor = System.Drawing.Color.Red;
                txttotalFail.Text = failed.ToString();
                txtFailedCode.BorderColor = System.Drawing.Color.Red;
                txtFailedCode.Text = code;
                txtGPA.Text = "F";
                txtTotalgp.Text = "0.00";
            }
            else
            {
                txtResult.Text = "Passed";
                txtFailedCode.Text = "";
                txttotalFail.Text = "";
                txtResult.ForeColor = System.Drawing.Color.Green;
                txtFailedCode.BorderColor = System.Drawing.Color.Silver;
            }
            if (txtResult.Text == "Passed")
            {
                double Total_gp;
                double GPA;
                double gp_5722 = Convert.ToDouble(Gp5722.Text);
                double gp_5812 = Convert.ToDouble(Gp5812.Text);
                double gp_5912 = Convert.ToDouble(Gp5912.Text);
                double gp_5921 = Convert.ToDouble(Gp5921.Text);
                double gp_6621 = Convert.ToDouble(Gp6621.Text);
                double gp_5711 = Convert.ToDouble(Gp5711.Text);
                double gp_6821 = Convert.ToDouble(Gp6821.Text);
                Total_gp = ((gp_5722 * 3) + (gp_5812 * 3) + (gp_5912 * 4) + (gp_5921 * 4) + (gp_6621 * 2) + (gp_5711 * 3) + (gp_6821 * 2));
                GPA = (Total_gp / 21);
                if (GPA >= 4.00)
                {
                    txtGPA.Text = "A+";
                    txtTotalgp.Text = "4.00";
                }
                else if (GPA >= 3.75 && GPA < 4.00)
                {
                    txtGPA.Text = "A";
                    txtTotalgp.Text = "3.75";
                }
                else if (GPA >= 3.50 && GPA < 3.75)
                {
                    txtGPA.Text = "A-";
                    txtTotalgp.Text = "3.50";
                }
                else if (GPA >= 3.25 && GPA < 3.50)
                {
                    txtGPA.Text = "B+";
                    txtTotalgp.Text = "3.25";
                }
                else if (GPA >= 3.00 && GPA < 3.25)
                {
                    txtGPA.Text = "B";
                    txtTotalgp.Text = "3.00";
                }
                else if (GPA >= 2.75 && GPA < 3.00)
                {
                    txtGPA.Text = "B-";
                    txtTotalgp.Text = "2.75";
                }
                else if (GPA >= 2.50 && GPA < 2.75)
                {
                    txtGPA.Text = "C+";
                    txtTotalgp.Text = "2.50";
                }
                else if (GPA >= 2.25 && GPA < 2.50)
                {
                    txtGPA.Text = "C";
                    txtTotalgp.Text = "2.25";
                }
                else if (GPA >= 2.00 && GPA < 2.25)
                {
                    txtGPA.Text = "D";
                    txtTotalgp.Text = "2.00";
                }
            }

            ////---------Database Code---------////

            Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = @"update Ct2nd set
            roll=@roll,
            type=@type,
            held=@held,
            year=@year,
            tc5722=@tc5722,
            tf5722=@tf5722,
            pc5722=@pc5722,
            total5722=@total5722,
            lg5722=@lg5722,
            gp5722=@gp5722,
            tc1012=@tc1012,
            tf1012=@tf1012,
            pc1012=@pc1012,
            pf1012=@pf1012,
            total5812=@total5812,
            lg5812=@lg5812,
            gp5812=@gp5812,
            tc5912=@tc5912,
            tf5912=@tf5912,
            pc5912=@pc5912,
            pf5912=@pf5912,
            total5912=@total5912,
            lg5912=@lg5912,
            gp5912=@gp5912,
            tc5921=@tc5921,
            tf5921=@tf5921,
            pc5921=@pc5921,
            total5921=@total5921,
            lg5921=@lg5921,
            gp5921=@gp5921,
            pc6621=@pc6621, 
            pf6621=@pf6621,
            total6621=@total6621,
            lg6621=@lg6621,
            gp6621=@gp6621,
            tc5711=@tc5711,
            tf5711=@tf5711,
            pc5711=@pc5711,
            pf6711=@pf6711,
            total5711=@total5711,
            lg5711=@lg5711,
            gp5711=@gp5711,
            tc6821=@tc6821,
            tf6821=@tf6821,
            total6821=@total6821,
            lg6821=@lg6821,
            gp6821=@gp6821,
            totalgp=@totalgp,
            gpa=@gpa,
            result=@result,
            totalfail=@totalfail,
            failcode=@failcode where roll=@id";
            cmd.Parameters.AddWithValue("@id", Session["id"].ToString());
            cmd.Parameters.AddWithValue("@roll", txtRoll.Text);
            cmd.Parameters.AddWithValue("@type", ddltype.SelectedValue);
            cmd.Parameters.AddWithValue("@held", ddlMonth.SelectedValue);
            cmd.Parameters.AddWithValue("@year", ddlYear.SelectedValue);
            cmd.Parameters.AddWithValue("@tc5722", Tc5722.Text);
            cmd.Parameters.AddWithValue("@tf5722", Tf5722.Text);
            cmd.Parameters.AddWithValue("@pc5722", Pc5722.Text);
            cmd.Parameters.AddWithValue("@total5722", Total5722.Text);
            cmd.Parameters.AddWithValue("@lg5722", Lg5722.Text);
            cmd.Parameters.AddWithValue("@gp5722", Gp5722.Text);
            cmd.Parameters.AddWithValue("@tc1012", Tc1012.Text);
            cmd.Parameters.AddWithValue("@tf1012", Tf1012.Text);
            cmd.Parameters.AddWithValue("@pc1012", Pc1012.Text);
            cmd.Parameters.AddWithValue("@pf1012", Pf1012.Text);
            cmd.Parameters.AddWithValue("@total5812", Total5812.Text);
            cmd.Parameters.AddWithValue("@lg5812", Lg5812.Text);
            cmd.Parameters.AddWithValue("@gp5812", Gp5812.Text);
            cmd.Parameters.AddWithValue("@tc5912", Tc5912.Text);
            cmd.Parameters.AddWithValue("@tf5912", Tf5912.Text);
            cmd.Parameters.AddWithValue("@pc5912", Pc5912.Text);
            cmd.Parameters.AddWithValue("@pf5912", Pf5912.Text);
            cmd.Parameters.AddWithValue("@total5912", Total5912.Text);
            cmd.Parameters.AddWithValue("@lg5912", Lg5912.Text);
            cmd.Parameters.AddWithValue("@gp5912", Gp5912.Text);
            cmd.Parameters.AddWithValue("@tc5921", Tc5921.Text);
            cmd.Parameters.AddWithValue("@tf5921", Tf5921.Text);
            cmd.Parameters.AddWithValue("@pc5921", Pc5921.Text);
            cmd.Parameters.AddWithValue("@total5921", Total5921.Text);
            cmd.Parameters.AddWithValue("@lg5921", Lg5921.Text);
            cmd.Parameters.AddWithValue("@gp5921", Gp5921.Text);
            cmd.Parameters.AddWithValue("@pc6621", Pc6621.Text);
            cmd.Parameters.AddWithValue("@pf6621", Pf6621.Text);
            cmd.Parameters.AddWithValue("@total6621", Total6621.Text);
            cmd.Parameters.AddWithValue("@lg6621", Lg6621.Text);
            cmd.Parameters.AddWithValue("@gp6621", Gp6621.Text);
            cmd.Parameters.AddWithValue("@tc5711", Tc5711.Text);
            cmd.Parameters.AddWithValue("@tf5711", Tf5711.Text);
            cmd.Parameters.AddWithValue("@pc5711", Pc5711.Text);
            cmd.Parameters.AddWithValue("@pf6711", Pf6711.Text);
            cmd.Parameters.AddWithValue("@total5711", Total5711.Text);
            cmd.Parameters.AddWithValue("@lg5711", Lg5711.Text);
            cmd.Parameters.AddWithValue("@gp5711", Gp5711.Text);
            cmd.Parameters.AddWithValue("@tc6821", Tc6821.Text);
            cmd.Parameters.AddWithValue("@tf6821", Tf6821.Text);
            cmd.Parameters.AddWithValue("@total6821", Total6821.Text);
            cmd.Parameters.AddWithValue("@lg6821", Lg6821.Text);
            cmd.Parameters.AddWithValue("@gp6821", Gp6821.Text);
            cmd.Parameters.AddWithValue("@totalgp", txtTotalgp.Text);
            cmd.Parameters.AddWithValue("@gpa", txtGPA.Text);
            cmd.Parameters.AddWithValue("@result", txtResult.Text);
            cmd.Parameters.AddWithValue("@totalfail", txttotalFail.Text);
            cmd.Parameters.AddWithValue("@failcode", txtFailedCode.Text);
            try
            {
                cmd.ExecuteNonQuery();
                lblmessage.Text = "Update Successfully";
                lblmessage.ForeColor = System.Drawing.Color.Green;
            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

        }
    }
}
