﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class Cmt2ndEdit : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString);
    private void Connection()
    {
        if (cn.State == ConnectionState.Open)
        {
            cn.Close();
        }

        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"].ToString() == "")
        {
            Server.Transfer("Default.aspx");
        }
        string id = Session["id"].ToString();
        if (!IsPostBack)
        {
            if (id != "" && id != null)
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = @"select Cmt2nd.* from 
                Cmt2nd where Cmt2nd.roll=@roll";
                cmd.Parameters.AddWithValue("@roll", id);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txtRoll.Text = dr["roll"].ToString();
                    ddltype.SelectedValue = dr["type"].ToString();
                    ddlMonth.SelectedValue = dr["held"].ToString();
                    ddlYear.SelectedValue = dr["year"].ToString();


                    Tc5722.Text = dr["tc5722"].ToString();
                    Tf5722.Text = dr["tf5722"].ToString();
                    Pc5722.Text = dr["pc5722"].ToString();
                    Pc5812.Text = dr["pc5812"].ToString();
                    Pf5812.Text = dr["pf5812"].ToString();
                    Tc5912.Text = dr["tc5912"].ToString();
                    Tf5912.Text = dr["tf5912"].ToString();
                    Pc5912.Text = dr["pc5912"].ToString();
                    Pf5912.Text = dr["pf5912"].ToString();
                    Tc5921.Text = dr["tc5921"].ToString();
                    Tf5921.Text = dr["tf5921"].ToString();
                    Pc5921.Text = dr["pc5921"].ToString();
                    Pc6621.Text = dr["pc6621"].ToString();
                    Pf6621.Text = dr["pf6621"].ToString();
                    Tc5711.Text = dr["tc5711"].ToString();
                    Tf5711.Text = dr["tf5711"].ToString();
                    Pc5711.Text = dr["pc5711"].ToString();
                    Tc6821.Text = dr["tc6821"].ToString();
                    Tf6821.Text = dr["tf6821"].ToString();
                    Pc6821.Text = dr["pc6821"].ToString();
                    Pf6821.Text = dr["pf6821"].ToString();
                    Pc7011.Text = dr["pc7011"].ToString();
                    Pf7011.Text = dr["pf7011"].ToString();

                    txttotalFail.Text = dr["totalfail"].ToString();
                    txtFailedCode.Text = dr["failcode"].ToString();
                    txtTotalgp.Text = dr["totalgp"].ToString();
                    txtGPA.Text = dr["gpa"].ToString();
                    txtResult.Text = dr["result"].ToString();

                    Total5722.Text = dr["total5722"].ToString();
                    Total5812.Text = dr["total5812"].ToString();
                    Total5912.Text = dr["total5912"].ToString();
                    Total5921.Text = dr["total5921"].ToString();
                    Total6621.Text = dr["total6621"].ToString();
                    Total5711.Text = dr["total5711"].ToString();
                    Total6821.Text = dr["total6821"].ToString();
                    Total7011.Text = dr["total7011"].ToString();
                    Lg5711.Text = dr["lg5711"].ToString();
                    Lg5722.Text = dr["lg5722"].ToString();
                    Lg5812.Text = dr["lg5812"].ToString();
                    Lg5912.Text = dr["lg5912"].ToString();
                    Lg5921.Text = dr["lg5921"].ToString();
                    Lg6621.Text = dr["lg6621"].ToString();
                    Lg6821.Text = dr["lg6821"].ToString();
                    Lg7011.Text = dr["lg7011"].ToString();
                    Gp5711.Text = dr["gp5711"].ToString();
                    Gp5722.Text = dr["gp5722"].ToString();
                    Gp5812.Text = dr["gp5812"].ToString();
                    Gp5912.Text = dr["gp5912"].ToString();
                    Gp5921.Text = dr["gp5921"].ToString();
                    Gp6621.Text = dr["gp6621"].ToString();
                    Gp6821.Text = dr["gp6821"].ToString();
                    Gp7011.Text = dr["gp7011"].ToString();

                }
            }
        }
    }
    protected void Btnsave_Click(object sender, EventArgs e)
    {
        ////-----Valition Code---------/////

        int err = 0;
        int txtTc5722 = Convert.ToInt32(Tc5722.Text);
        int txtTf5722 = Convert.ToInt32(Tf5722.Text);
        int txtPc5722 = Convert.ToInt32(Pc5722.Text);
        int txtPc5812 = Convert.ToInt32(Pc5812.Text);
        int txtPf5812 = Convert.ToInt32(Pf5812.Text);
        int txtTc5912 = Convert.ToInt32(Tc5912.Text);
        int txtTf5912 = Convert.ToInt32(Tf5912.Text);
        int txtPc5912 = Convert.ToInt32(Pc5912.Text);
        int txtPf5912 = Convert.ToInt32(Pf5912.Text);
        int txtTc5921 = Convert.ToInt32(Tc5921.Text);
        int txtTf5921 = Convert.ToInt32(Tf5921.Text);
        int txtPc5921 = Convert.ToInt32(Pc5921.Text);
        int txtPc6621 = Convert.ToInt32(Pc6621.Text);
        int txtPf6621 = Convert.ToInt32(Pf6621.Text);
        int txtTc5711 = Convert.ToInt32(Tc5711.Text);
        int txtTf5711 = Convert.ToInt32(Tf5711.Text);
        int txtPc5711 = Convert.ToInt32(Pc5711.Text);
        int txtTc6821 = Convert.ToInt32(Tc6821.Text);
        int txtTf6821 = Convert.ToInt32(Tf6821.Text);
        int txtPc6821 = Convert.ToInt32(Pc6821.Text);
        int txtPf6821 = Convert.ToInt32(Pf6821.Text);
        int txtPc7011 = Convert.ToInt32(Pc7011.Text);
        int txtPf7011 = Convert.ToInt32(Pf7011.Text);

        if (txtRoll.Text == "")
        {
            err++;
            lblmessage.Text = "Roll Number Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            txtRoll.Focus();
        }
        else if (ddltype.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Type Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddltype.Focus();
        }
        else if (ddlMonth.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Month Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddlMonth.Focus();
        }
        else if (ddlYear.SelectedIndex == 0)
        {
            err++;
            lblmessage.Text = "Year Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            ddlYear.Focus();
        }
        else if (txtTc5722 > 20)
        {
            err++;
            lblmessage.Text = "Required Number <=20";
            Tc5722.Focus();
        }
        else if (txtTf5722 > 80)
        {
            err++;
            lblmessage.Text = "Required Number <=80";
            Tf5722.Focus();
        }
        else if (txtPc5722 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc5722.Focus();
        }
        else if (txtPc5812 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pc5812.Focus();
        }
        else if (txtPf5812 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pf5812.Focus();
        }
        else if (txtTc5912 > 30)
        {
            err++;
            lblmessage.Text = "Required Number <=30";
            Tc5912.Focus();
        }
        else if (txtTf5912 > 120)
        {
            err++;
            lblmessage.Text = "Required Number <=120";
            Tf5912.Focus();
        }
        else if (txtPc5912 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pc5912.Focus();
        }
        else if (txtPf5912 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pf5912.Focus();
        }
        else if (txtTc5921 > 30)
        {
            err++;
            lblmessage.Text = "Required Number <=30";
            Tc5921.Focus();
        }
        else if (txtTf5921 > 120)
        {
            err++;
            lblmessage.Text = "Required Number <=120";
            Tf5921.Focus();
        }
        else if (txtPc5921 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc5921.Focus();
        }
        else if (txtPc6621 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc6621.Focus();
        }
        else if (txtPf6621 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pf6621.Focus();
        }
        else if (txtTc5711 > 20)
        {
            err++;
            lblmessage.Text = "Required Number <=20";
            Tc5711.Focus();
        }
        else if (txtTf5711 > 80)
        {
            err++;
            lblmessage.Text = "Required Number <=80";
            Tf5711.Focus();
        }
        else if (txtPc5711 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc5711.Focus();
        }
        else if (txtTc6821 > 30)
        {
            err++;
            lblmessage.Text = "Required Number <=30";
            Tc6821.Focus();
        }
        else if (txtTf6821 > 120)
        {
            err++;
            lblmessage.Text = "Required Number <=120";
            Tf6821.Focus();
        }
        else if (txtPc6821 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pc6821.Focus();
        }
        else if (txtPf6821 > 25)
        {
            err++;
            lblmessage.Text = "Required Number <=25";
            Pf6821.Focus();
        }
        else if (txtPc7011 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pc7011.Focus();
        }
        else if (txtPf7011 > 50)
        {
            err++;
            lblmessage.Text = "Required Number <=50";
            Pf7011.Focus();
        }
        else if (Total5722.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5722.BorderColor = System.Drawing.Color.Red;
            Tf5722.BorderColor = System.Drawing.Color.Red;
            Pc5722.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5722.Focus();
        }
        else if (Total5812.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Pf5812.BorderColor = System.Drawing.Color.Red;
            Pc5812.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5812.Focus();
        }
        else if (Total5912.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5912.BorderColor = System.Drawing.Color.Red;
            Tf5912.BorderColor = System.Drawing.Color.Red;
            Pc5912.BorderColor = System.Drawing.Color.Red;
            Pf5912.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5912.Focus();
        }
        else if (Total5921.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5921.BorderColor = System.Drawing.Color.Red;
            Tf5921.BorderColor = System.Drawing.Color.Red;
            Pc5921.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5921.Focus();
        }
        else if (Total6621.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Pf6621.BorderColor = System.Drawing.Color.Red;
            Pc6621.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc6621.Focus();
        }
        else if (Total5711.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc5711.BorderColor = System.Drawing.Color.Red;
            Tf5711.BorderColor = System.Drawing.Color.Red;
            Pc5711.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5711.Focus();
        }
        else if (Total6821.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Tc6821.BorderColor = System.Drawing.Color.Red;
            Tf6821.BorderColor = System.Drawing.Color.Red;
            Pc6821.BorderColor = System.Drawing.Color.Red;
            Pf6821.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc6821.Focus();
        }
        else if (Total7011.Text == "")
        {
            err++;
            lblmessage.Text = "Required";
            Pf7011.BorderColor = System.Drawing.Color.Red;
            Pc7011.BorderColor = System.Drawing.Color.Red;
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc7011.Focus();
        }
        if (err == 0)
        {

            ///---- Calculation Code----///

            int failed = 0;
            string code = "";
            if (Lg5722.Text == "F")
            {
                failed++;
                code = "5722";
            }
            if (Lg5812.Text == "F")
            {
                failed++;
                code = code + " " + "5812";
            }
            if (Lg5912.Text == "F")
            {
                failed++;
                code = code + " " + "5912";
            }
            if (Lg5921.Text == "F")
            {
                failed++;
                code = code + " " + "5921";
            }
            if (Lg6621.Text == "F")
            {
                failed++;
                code = code + " " + "6621";
            }
            if (Lg5711.Text == "F")
            {
                failed++;
                code = code + " " + "5711";
            }
            if (Lg6821.Text == "F")
            {
                failed++;
                code = code + " " + "6821";
            }
            if (Lg7011.Text == "F")
            {
                failed++;
                code = code + " " + "7011";
            }
            if (failed > 2)
            {
                txtResult.Text = "Failed";
                txtResult.ForeColor = System.Drawing.Color.Red;
                txttotalFail.Text = failed.ToString();
                txtFailedCode.BorderColor = System.Drawing.Color.Red;
                txtFailedCode.Text = code;
                txtGPA.Text = "F";
                txtTotalgp.Text = "0.00";
            }
            else if (failed > 0 && failed <= 2)
            {
                txtResult.Text = "Reffard";
                txtResult.ForeColor = System.Drawing.Color.Red;
                txttotalFail.Text = failed.ToString();
                txtFailedCode.BorderColor = System.Drawing.Color.Red;
                txtFailedCode.Text = code;
                txtGPA.Text = "F";
                txtTotalgp.Text = "0.00";
            }
            else
            {
                txtResult.Text = "Passed";
                txtFailedCode.Text = "";
                txttotalFail.Text = "";
                txtResult.ForeColor = System.Drawing.Color.Green;
                txtFailedCode.BorderColor = System.Drawing.Color.Silver;
            }
            if (txtResult.Text == "Passed")
            {
                double Total_gp;
                double GPA;
                double gp_5722 = Convert.ToDouble(Gp5722.Text);
                double gp_5812 = Convert.ToDouble(Gp5812.Text);
                double gp_5912 = Convert.ToDouble(Gp5912.Text);
                double gp_5921 = Convert.ToDouble(Gp5921.Text);
                double gp_6621 = Convert.ToDouble(Gp6621.Text);
                double gp_5711 = Convert.ToDouble(Gp5711.Text);
                double gp_6821 = Convert.ToDouble(Gp6821.Text);
                double gp_7011 = Convert.ToDouble(Gp7011.Text);
                Total_gp = ((gp_5722 * 3) + (gp_5812 * 1) + (gp_5912 * 4) + (gp_5921 * 4) + (gp_6621 * 2) + (gp_5711 * 3) + (gp_6821 * 4) + (gp_7011 * 2));
                GPA = (Total_gp / 23);
                if (GPA >= 4.00)
                {
                    txtGPA.Text = "A+";
                    txtTotalgp.Text = "4.00";
                }
                else if (GPA >= 3.75 && GPA < 4.00)
                {
                    txtGPA.Text = "A";
                    txtTotalgp.Text = "3.75";
                }
                else if (GPA >= 3.50 && GPA < 3.75)
                {
                    txtGPA.Text = "A-";
                    txtTotalgp.Text = "3.50";
                }
                else if (GPA >= 3.25 && GPA < 3.50)
                {
                    txtGPA.Text = "B+";
                    txtTotalgp.Text = "3.25";
                }
                else if (GPA >= 3.00 && GPA < 3.25)
                {
                    txtGPA.Text = "B";
                    txtTotalgp.Text = "3.00";
                }
                else if (GPA >= 2.75 && GPA < 3.00)
                {
                    txtGPA.Text = "B-";
                    txtTotalgp.Text = "2.75";
                }
                else if (GPA >= 2.50 && GPA < 2.75)
                {
                    txtGPA.Text = "C+";
                    txtTotalgp.Text = "2.50";
                }
                else if (GPA >= 2.25 && GPA < 2.50)
                {
                    txtGPA.Text = "C";
                    txtTotalgp.Text = "2.25";
                }
                else if (GPA >= 2.00 && GPA < 2.25)
                {
                    txtGPA.Text = "D";
                    txtTotalgp.Text = "2.00";
                }
            }

            ////---------Database Code---------////

            Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = @"update Cmt2nd set
            roll=@roll,
            type=@type,
            held=@held,
            year=@year,
            tc5722=@tc5722,
            tf5722=@tf5722,
            pc5722=@pc5722,
            total5722=@total5722,
            lg5722=@lg5722,
            gp5722=@gp5722,
            pc5812=@pc5812,
            pf5812=@pf5812,
            total5812=@total5812,
            lg5812=@lg5812,
            gp5812=@gp5812,
            tc5912=@tc5912,
            tf5912=@tf5912,
            pc5912=@pc5912,
            pf5912=@pf5912,
            total5912=@total5912,
            lg5912=@lg5912,
            gp5912=@gp5912,
            tc5921=@tc5921,
            tf5921=@tf5921,
            pc5921=@pc5921,
            total5921=@total5921,
            lg5921=@lg5921,
            gp5921=@gp5921,
            pc6621=@pc6621, 
            pf6621=@pf6621,
            total6621=@total6621,
            lg6621=@lg6621,
            gp6621=@gp6621,
            tc5711=@tc5711,
            tf5711=@tf5711,
            pc5711=@pc5711,
            total5711=@total5711,
            lg5711=@lg5711,
            gp5711=@gp5711,
            tc6821=@tc6821,
            tf6821=@tf6821,
            pc6821=@pc6821,
            pf6821=@pf6821,
            total6821=@total6821,
            lg6821=@lg6821,
            gp6821=@gp6821,
            pc7011=@pc7011,
            pf7011=@pf7011,
            total7011=@total7011,
            lg7011=@lg7011,
            gp7011=@gp7011,
            totalgp=@totalgp,
            gpa=@gpa,
            result=@result,
            totalfail=@totalfail,
            failcode=@failcode where roll=@id";
            cmd.Parameters.AddWithValue("@id", Session["id"].ToString());
            cmd.Parameters.AddWithValue("@roll", txtRoll.Text);
            cmd.Parameters.AddWithValue("@type", ddltype.SelectedValue);
            cmd.Parameters.AddWithValue("@held", ddlMonth.SelectedValue);
            cmd.Parameters.AddWithValue("@year", ddlYear.SelectedValue);
            cmd.Parameters.AddWithValue("@tc5722", Tc5722.Text);
            cmd.Parameters.AddWithValue("@tf5722", Tf5722.Text);
            cmd.Parameters.AddWithValue("@pc5722", Pc5722.Text);
            cmd.Parameters.AddWithValue("@total5722", Total5722.Text);
            cmd.Parameters.AddWithValue("@lg5722", Lg5722.Text);
            cmd.Parameters.AddWithValue("@gp5722", Gp5722.Text);
            cmd.Parameters.AddWithValue("@pc5812", Pc5812.Text);
            cmd.Parameters.AddWithValue("@pf5812", Pf5812.Text);
            cmd.Parameters.AddWithValue("@total5812", Total5812.Text);
            cmd.Parameters.AddWithValue("@lg5812", Lg5812.Text);
            cmd.Parameters.AddWithValue("@gp5812", Gp5812.Text);
            cmd.Parameters.AddWithValue("@tc5912", Tc5912.Text);
            cmd.Parameters.AddWithValue("@tf5912", Tf5912.Text);
            cmd.Parameters.AddWithValue("@pc5912", Pc5912.Text);
            cmd.Parameters.AddWithValue("@pf5912", Pf5912.Text);
            cmd.Parameters.AddWithValue("@total5912", Total5912.Text);
            cmd.Parameters.AddWithValue("@lg5912", Lg5912.Text);
            cmd.Parameters.AddWithValue("@gp5912", Gp5912.Text);
            cmd.Parameters.AddWithValue("@tc5921", Tc5921.Text);
            cmd.Parameters.AddWithValue("@tf5921", Tf5921.Text);
            cmd.Parameters.AddWithValue("@pc5921", Pc5921.Text);
            cmd.Parameters.AddWithValue("@total5921", Total5921.Text);
            cmd.Parameters.AddWithValue("@lg5921", Lg5921.Text);
            cmd.Parameters.AddWithValue("@gp5921", Gp5921.Text);
            cmd.Parameters.AddWithValue("@pc6621", Pc6621.Text);
            cmd.Parameters.AddWithValue("@pf6621", Pf6621.Text);
            cmd.Parameters.AddWithValue("@total6621", Total6621.Text);
            cmd.Parameters.AddWithValue("@lg6621", Lg6621.Text);
            cmd.Parameters.AddWithValue("@gp6621", Gp6621.Text);
            cmd.Parameters.AddWithValue("@tc5711", Tc5711.Text);
            cmd.Parameters.AddWithValue("@tf5711", Tf5711.Text);
            cmd.Parameters.AddWithValue("@pc5711", Pc5711.Text);
            cmd.Parameters.AddWithValue("@total5711", Total5711.Text);
            cmd.Parameters.AddWithValue("@lg5711", Lg5711.Text);
            cmd.Parameters.AddWithValue("@gp5711", Gp5711.Text);
            cmd.Parameters.AddWithValue("@tc6821", Tc6821.Text);
            cmd.Parameters.AddWithValue("@tf6821", Tf6821.Text);
            cmd.Parameters.AddWithValue("@pc6821", Pc6821.Text);
            cmd.Parameters.AddWithValue("@pf6821", Pf6821.Text);
            cmd.Parameters.AddWithValue("@total6821", Total6821.Text);
            cmd.Parameters.AddWithValue("@lg6821", Lg6821.Text);
            cmd.Parameters.AddWithValue("@gp6821", Gp6821.Text);
            cmd.Parameters.AddWithValue("@pc7011", Pc7011.Text);
            cmd.Parameters.AddWithValue("@pf7011", Pf7011.Text);
            cmd.Parameters.AddWithValue("@total7011", Total7011.Text);
            cmd.Parameters.AddWithValue("@lg7011", Lg7011.Text);
            cmd.Parameters.AddWithValue("@gp7011", Gp7011.Text);
            cmd.Parameters.AddWithValue("@totalgp", txtTotalgp.Text);
            cmd.Parameters.AddWithValue("@gpa", txtGPA.Text);
            cmd.Parameters.AddWithValue("@result", txtResult.Text);
            cmd.Parameters.AddWithValue("@totalfail", txttotalFail.Text);
            cmd.Parameters.AddWithValue("@failcode", txtFailedCode.Text);
            try
            {
                cmd.ExecuteNonQuery();
                lblmessage.Text = "Update Successfully";
                lblmessage.ForeColor = System.Drawing.Color.Green;
            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }


        }
    }
    protected void Tc5722_TextChanged(object sender, EventArgs e)
    {

        int Total_5722;
        int tctxt = Convert.ToInt32(Tc5722.Text);
        int tftxt = Convert.ToInt32(Tf5722.Text);
        int pctxt = Convert.ToInt32(Pc5722.Text);

        if (tctxt >= 0 && tctxt <= 20)
        {
            int tc_tf = (tctxt + tftxt);

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5722 = (tc_tf + pctxt);
            }
            else
            {
                Total_5722 = 0;
            }

            //-----5722--------//

            if (Total_5722 >= 120)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "4.00";
                Lg5722.Text = "A+";
            }
            else if (Total_5722 >= 112.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.75";
                Lg5722.Text = "A";
            }
            else if (Total_5722 >= 105)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.50";
                Lg5722.Text = "A-";
            }
            else if (Total_5722 >= 97.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.25";
                Lg5722.Text = "B+";
            }
            else if (Total_5722 >= 90)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.00";
                Lg5722.Text = "B";
            }
            else if (Total_5722 >= 82.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.75";
                Lg5722.Text = "B-";
            }
            else if (Total_5722 >= 75)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.50";
                Lg5722.Text = "C+";
            }
            else if (Total_5722 >= 67.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.25";
                Lg5722.Text = "C";
            }
            else if (Total_5722 >= 60)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.00";
                Lg5722.Text = "D";
            }
            else
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "0.00";
                Lg5722.Text = "F";
            }
            Tf5722.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=20 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5722.Focus();
        }

    }
    protected void Tf5722_TextChanged(object sender, EventArgs e)
    {
        int Total_5722;
        int tctxt = Convert.ToInt32(Tc5722.Text);
        int tftxt = Convert.ToInt32(Tf5722.Text);
        int pctxt = Convert.ToInt32(Pc5722.Text);
        if (tftxt >= 0 && tftxt <= 80)
        {
            int tc_tf = (tctxt + tftxt);

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5722 = (tc_tf + pctxt);
            }
            else
            {
                Total_5722 = 0;
            }

            //-----5722--------//

            if (Total_5722 >= 120)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "4.00";
                Lg5722.Text = "A+";
            }
            else if (Total_5722 >= 112.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.75";
                Lg5722.Text = "A";
            }
            else if (Total_5722 >= 105)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.50";
                Lg5722.Text = "A-";
            }
            else if (Total_5722 >= 97.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.25";
                Lg5722.Text = "B+";
            }
            else if (Total_5722 >= 90)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.00";
                Lg5722.Text = "B";
            }
            else if (Total_5722 >= 82.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.75";
                Lg5722.Text = "B-";
            }
            else if (Total_5722 >= 75)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.50";
                Lg5722.Text = "C+";
            }
            else if (Total_5722 >= 67.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.25";
                Lg5722.Text = "C";
            }
            else if (Total_5722 >= 60)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.00";
                Lg5722.Text = "D";
            }
            else
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "0.00";
                Lg5722.Text = "F";
            }
            Pc5722.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=80 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5722.Focus();
        }

    }
    protected void Pc5722_TextChanged(object sender, EventArgs e)
    {
        int Total_5722;
        int tctxt = Convert.ToInt32(Tc5722.Text);
        int tftxt = Convert.ToInt32(Tf5722.Text);
        int pctxt = Convert.ToInt32(Pc5722.Text);
        int tc_tf = (tctxt + tftxt);

        if (pctxt >= 0 && pctxt <= 50)
        {

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5722 = (tc_tf + pctxt);
            }
            else
            {
                Total_5722 = 0;
            }

            //-----5722--------//

            if (Total_5722 >= 120)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "4.00";
                Lg5722.Text = "A+";
            }
            else if (Total_5722 >= 112.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.75";
                Lg5722.Text = "A";
            }
            else if (Total_5722 >= 105)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.50";
                Lg5722.Text = "A-";
            }
            else if (Total_5722 >= 97.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.25";
                Lg5722.Text = "B+";
            }
            else if (Total_5722 >= 90)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "3.00";
                Lg5722.Text = "B";
            }
            else if (Total_5722 >= 82.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.75";
                Lg5722.Text = "B-";
            }
            else if (Total_5722 >= 75)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.50";
                Lg5722.Text = "C+";
            }
            else if (Total_5722 >= 67.5)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.25";
                Lg5722.Text = "C";
            }
            else if (Total_5722 >= 60)
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "2.00";
                Lg5722.Text = "D";
            }
            else
            {
                Total5722.Text = Total_5722.ToString();
                Gp5722.Text = "0.00";
                Lg5722.Text = "F";
            }
            Pc5812.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5722.Focus();
        }
    }
    protected void Pc5812_TextChanged(object sender, EventArgs e)
    {
        int Total_5812;
        int pctxt = Convert.ToInt32(Pc5812.Text);
        int pftxt = Convert.ToInt32(Pf5812.Text);

        if (pctxt >= 0 && pctxt <= 25)
        {
            if (pctxt >= 10 && pftxt >= 10)
            {
                Total_5812 = (pctxt + pftxt);
            }
            else
            {
                Total_5812 = 0;
            }

            //-----5812--------//

            if (Total_5812 >= 40)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "4.00";
                Lg5812.Text = "A+";
            }
            else if (Total_5812 >= 37.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.75";
                Lg5812.Text = "A";
            }
            else if (Total_5812 >= 35)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.50";
                Lg5812.Text = "A-";
            }
            else if (Total_5812 >= 32.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.25";
                Lg5812.Text = "B+";
            }
            else if (Total_5812 >= 30)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.00";
                Lg5812.Text = "B";
            }
            else if (Total_5812 >= 27.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.75";
                Lg5812.Text = "B-";
            }
            else if (Total_5812 >= 25)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.50";
                Lg5812.Text = "C+";
            }
            else if (Total_5812 >= 22.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.25";
                Lg5812.Text = "C";
            }
            else if (Total_5812 >= 20)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.00";
                Lg5812.Text = "D";
            }
            else
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "0.00";
                Lg5812.Text = "F";
            }
            Pf5812.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5812.Focus();
        }
    }
    protected void Pf5812_TextChanged(object sender, EventArgs e)
    {
        int Total_5812;
        int pctxt = Convert.ToInt32(Pc5812.Text);
        int pftxt = Convert.ToInt32(Pf5812.Text);

        if (pftxt >= 0 && pftxt <= 25)
        {
            if (pctxt >= 10 && pftxt >= 10)
            {
                Total_5812 = (pctxt + pftxt);
            }
            else
            {
                Total_5812 = 0;
            }

            //-----5812--------//

            if (Total_5812 >= 40)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "4.00";
                Lg5812.Text = "A+";
            }
            else if (Total_5812 >= 37.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.75";
                Lg5812.Text = "A";
            }
            else if (Total_5812 >= 35)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.50";
                Lg5812.Text = "A-";
            }
            else if (Total_5812 >= 32.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.25";
                Lg5812.Text = "B+";
            }
            else if (Total_5812 >= 30)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "3.00";
                Lg5812.Text = "B";
            }
            else if (Total_5812 >= 27.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.75";
                Lg5812.Text = "B-";
            }
            else if (Total_5812 >= 25)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.50";
                Lg5812.Text = "C+";
            }
            else if (Total_5812 >= 22.5)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.25";
                Lg5812.Text = "C";
            }
            else if (Total_5812 >= 20)
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "2.00";
                Lg5812.Text = "D";
            }
            else
            {
                Total5812.Text = Total_5812.ToString();
                Gp5812.Text = "0.00";
                Lg5812.Text = "F";
            }
            Tc5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf5812.Focus();
        }
    }
    protected void Tc5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);



        if (tctxt >= 0 && tctxt <= 30)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Tf5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=30 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5912.Focus();
        }
    }
    protected void Tf5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);

        if (tftxt >= 0 && tftxt <= 120)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Pc5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=120 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5912.Focus();
        }
    }
    protected void Pc5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);

        if (pctxt >= 0 && pctxt <= 25)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Pf5912.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5912.Focus();
        }
    }
    protected void Pf5912_TextChanged(object sender, EventArgs e)
    {
        int Total_5912;
        int tctxt = Convert.ToInt32(Tc5912.Text);
        int tftxt = Convert.ToInt32(Tf5912.Text);
        int pctxt = Convert.ToInt32(Pc5912.Text);
        int pftxt = Convert.ToInt32(Pf5912.Text);
        int tc_tf = (tctxt + tftxt);

        if (pftxt >= 0 && pftxt <= 25)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_5912 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_5912 = 0;
            }

            //-----5912--------//

            if (Total_5912 >= 160)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "4.00";
                Lg5912.Text = "A+";
            }
            else if (Total_5912 >= 150)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.75";
                Lg5912.Text = "A";
            }
            else if (Total_5912 >= 140)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.50";
                Lg5912.Text = "A-";
            }
            else if (Total_5912 >= 130)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.25";
                Lg5912.Text = "B+";
            }
            else if (Total_5912 >= 120)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "3.00";
                Lg5912.Text = "B";
            }
            else if (Total_5912 >= 110)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.75";
                Lg5912.Text = "B-";
            }
            else if (Total_5912 >= 100)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.50";
                Lg5912.Text = "C+";
            }
            else if (Total_5912 >= 90)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.25";
                Lg5912.Text = "C";
            }
            else if (Total_5912 >= 80)
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "2.00";
                Lg5912.Text = "D";
            }
            else
            {
                Total5912.Text = Total_5912.ToString();
                Gp5912.Text = "0.00";
                Lg5912.Text = "F";
            }
            Tc5921.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf5912.Focus();
        }
    }
    protected void Tc5921_TextChanged(object sender, EventArgs e)
    {
        int Total_5921;
        int tctxt = Convert.ToInt32(Tc5921.Text);
        int tftxt = Convert.ToInt32(Tf5921.Text);
        int pctxt = Convert.ToInt32(Pc5921.Text);
        int tc_tf = (tctxt + tftxt);

        if (tctxt >= 0 && tctxt <= 30)
        {

            if (tc_tf >= 60 && pctxt >= 20)
            {
                Total_5921 = (tc_tf + pctxt);
            }
            else
            {
                Total_5921 = 0;
            }

            //-----5921--------//

            if (Total_5921 >= 160)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "4.00";
                Lg5921.Text = "A+";
            }
            else if (Total_5921 >= 150)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.75";
                Lg5921.Text = "A";
            }
            else if (Total_5921 >= 140)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.50";
                Lg5921.Text = "A-";
            }
            else if (Total_5921 >= 130)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.25";
                Lg5921.Text = "B+";
            }
            else if (Total_5921 >= 120)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.00";
                Lg5921.Text = "B";
            }
            else if (Total_5921 >= 110)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.75";
                Lg5921.Text = "B-";
            }
            else if (Total_5921 >= 100)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.50";
                Lg5921.Text = "C+";
            }
            else if (Total_5921 >= 90)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.25";
                Lg5921.Text = "C";
            }
            else if (Total_5921 >= 80)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.00";
                Lg5921.Text = "D";
            }
            else
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "0.00";
                Lg5921.Text = "F";
            }
            Tf5921.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=30 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5921.Focus();
        }
    }
    protected void Tf5921_TextChanged(object sender, EventArgs e)
    {
        int Total_5921;
        int tctxt = Convert.ToInt32(Tc5921.Text);
        int tftxt = Convert.ToInt32(Tf5921.Text);
        int pctxt = Convert.ToInt32(Pc5921.Text);
        int tc_tf = (tctxt + tftxt);



        if (tftxt >= 0 && tftxt <= 120)
        {

            if (tc_tf >= 60 && pctxt >= 20)
            {
                Total_5921 = (tc_tf + pctxt);
            }
            else
            {
                Total_5921 = 0;
            }

            //-----5921--------//

            if (Total_5921 >= 160)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "4.00";
                Lg5921.Text = "A+";
            }
            else if (Total_5921 >= 150)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.75";
                Lg5921.Text = "A";
            }
            else if (Total_5921 >= 140)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.50";
                Lg5921.Text = "A-";
            }
            else if (Total_5921 >= 130)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.25";
                Lg5921.Text = "B+";
            }
            else if (Total_5921 >= 120)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.00";
                Lg5921.Text = "B";
            }
            else if (Total_5921 >= 110)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.75";
                Lg5921.Text = "B-";
            }
            else if (Total_5921 >= 100)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.50";
                Lg5921.Text = "C+";
            }
            else if (Total_5921 >= 90)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.25";
                Lg5921.Text = "C";
            }
            else if (Total_5921 >= 80)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.00";
                Lg5921.Text = "D";
            }
            else
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "0.00";
                Lg5921.Text = "F";
            }
            Pc5921.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=120 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5921.Focus();
        }
    }
    protected void Pc5921_TextChanged(object sender, EventArgs e)
    {
        int Total_5921;
        int tctxt = Convert.ToInt32(Tc5921.Text);
        int tftxt = Convert.ToInt32(Tf5921.Text);
        int pctxt = Convert.ToInt32(Pc5921.Text);
        int tc_tf = (tctxt + tftxt);


        if (pctxt >= 0 && pctxt <= 50)
        {

            if (tc_tf >= 60 && pctxt >= 20)
            {
                Total_5921 = (tc_tf + pctxt);
            }
            else
            {
                Total_5921 = 0;
            }

            //-----5921--------//

            if (Total_5921 >= 160)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "4.00";
                Lg5921.Text = "A+";
            }
            else if (Total_5921 >= 150)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.75";
                Lg5921.Text = "A";
            }
            else if (Total_5921 >= 140)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.50";
                Lg5921.Text = "A-";
            }
            else if (Total_5921 >= 130)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.25";
                Lg5921.Text = "B+";
            }
            else if (Total_5921 >= 120)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "3.00";
                Lg5921.Text = "B";
            }
            else if (Total_5921 >= 110)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.75";
                Lg5921.Text = "B-";
            }
            else if (Total_5921 >= 100)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.50";
                Lg5921.Text = "C+";
            }
            else if (Total_5921 >= 90)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.25";
                Lg5921.Text = "C";
            }
            else if (Total_5921 >= 80)
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "2.00";
                Lg5921.Text = "D";
            }
            else
            {
                Total5921.Text = Total_5921.ToString();
                Gp5921.Text = "0.00";
                Lg5921.Text = "F";
            }
            Pc6621.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5921.Focus();
        }



    }
    protected void Pc6621_TextChanged(object sender, EventArgs e)
    {
        int Total_6621;
        int pctxt = Convert.ToInt32(Pc6621.Text);
        int pftxt = Convert.ToInt32(Pf6621.Text);

        if (pctxt >= 0 && pctxt <= 50)
        {

            if (pctxt >= 20 && pftxt >= 20)
            {
                Total_6621 = (pctxt + pftxt);
            }
            else
            {
                Total_6621 = 0;
            }

            //-----6621--------//

            if (Total_6621 >= 80)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "4.00";
                Lg6621.Text = "A+";
            }
            else if (Total_6621 >= 75)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.75";
                Lg6621.Text = "A";
            }
            else if (Total_6621 >= 70)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.50";
                Lg6621.Text = "A-";
            }
            else if (Total_6621 >= 65)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.25";
                Lg6621.Text = "B+";
            }
            else if (Total_6621 >= 60)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.00";
                Lg6621.Text = "B";
            }
            else if (Total_6621 >= 55)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.75";
                Lg6621.Text = "B-";
            }
            else if (Total_6621 >= 50)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.50";
                Lg6621.Text = "C+";
            }
            else if (Total_6621 >= 45)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.25";
                Lg6621.Text = "C";
            }
            else if (Total_6621 >= 40)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.00";
                Lg6621.Text = "D";
            }
            else
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "0.00";
                Lg6621.Text = "F";
            }
            Pf6621.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc6621.Focus();
        }
    }
    protected void Pf6621_TextChanged(object sender, EventArgs e)
    {
        int Total_6621;
        int pctxt = Convert.ToInt32(Pc6621.Text);
        int pftxt = Convert.ToInt32(Pf6621.Text);


        if (pftxt >= 0 && pftxt <= 50)
        {

            if (pctxt >= 20 && pftxt >= 20)
            {
                Total_6621 = (pctxt + pftxt);
            }
            else
            {
                Total_6621 = 0;
            }

            //-----6621--------//

            if (Total_6621 >= 80)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "4.00";
                Lg6621.Text = "A+";
            }
            else if (Total_6621 >= 75)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.75";
                Lg6621.Text = "A";
            }
            else if (Total_6621 >= 70)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.50";
                Lg6621.Text = "A-";
            }
            else if (Total_6621 >= 65)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.25";
                Lg6621.Text = "B+";
            }
            else if (Total_6621 >= 60)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "3.00";
                Lg6621.Text = "B";
            }
            else if (Total_6621 >= 55)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.75";
                Lg6621.Text = "B-";
            }
            else if (Total_6621 >= 50)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.50";
                Lg6621.Text = "C+";
            }
            else if (Total_6621 >= 45)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.25";
                Lg6621.Text = "C";
            }
            else if (Total_6621 >= 40)
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "2.00";
                Lg6621.Text = "D";
            }
            else
            {
                Total6621.Text = Total_6621.ToString();
                Gp6621.Text = "0.00";
                Lg6621.Text = "F";
            }
            Tc5711.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf6621.Focus();
        }

    }
    protected void Tc5711_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc5711.Text);
        int tftxt = Convert.ToInt32(Tf5711.Text);
        int pctxt = Convert.ToInt32(Pc5711.Text);
        int tc_tf = (tctxt + tftxt);



        if (tctxt >= 0 && tctxt <= 20)
        {

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5711 = (tc_tf + pctxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "4.00";
                Lg5711.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.75";
                Lg5711.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.50";
                Lg5711.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.25";
                Lg5711.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.00";
                Lg5711.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.75";
                Lg5711.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.50";
                Lg5711.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.25";
                Lg5711.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.00";
                Lg5711.Text = "D";
            }
            else
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "0.00";
                Lg5711.Text = "F";
            }
            Tf5711.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=20 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc5711.Focus();
        }
    }
    protected void Tf5711_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc5711.Text);
        int tftxt = Convert.ToInt32(Tf5711.Text);
        int pctxt = Convert.ToInt32(Pc5711.Text);
        int tc_tf = (tctxt + tftxt);


        if (tftxt >= 0 && tftxt <= 80)
        {

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5711 = (tc_tf + pctxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "4.00";
                Lg5711.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.75";
                Lg5711.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.50";
                Lg5711.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.25";
                Lg5711.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.00";
                Lg5711.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.75";
                Lg5711.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.50";
                Lg5711.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.25";
                Lg5711.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.00";
                Lg5711.Text = "D";
            }
            else
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "0.00";
                Lg5711.Text = "F";
            }
            Pc5711.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=80 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf5711.Focus();
        }
    }
    protected void Pc5711_TextChanged(object sender, EventArgs e)
    {
        int Total_5711;
        int tctxt = Convert.ToInt32(Tc5711.Text);
        int tftxt = Convert.ToInt32(Tf5711.Text);
        int pctxt = Convert.ToInt32(Pc5711.Text);
        int tc_tf = (tctxt + tftxt);


        if (pctxt >= 0 && pctxt <= 50)
        {

            if (tc_tf >= 40 && pctxt >= 20)
            {
                Total_5711 = (tc_tf + pctxt);
            }
            else
            {
                Total_5711 = 0;
            }

            //-----5711--------//

            if (Total_5711 >= 120)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "4.00";
                Lg5711.Text = "A+";
            }
            else if (Total_5711 >= 112.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.75";
                Lg5711.Text = "A";
            }
            else if (Total_5711 >= 105)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.50";
                Lg5711.Text = "A-";
            }
            else if (Total_5711 >= 97.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.25";
                Lg5711.Text = "B+";
            }
            else if (Total_5711 >= 90)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "3.00";
                Lg5711.Text = "B";
            }
            else if (Total_5711 >= 82.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.75";
                Lg5711.Text = "B-";
            }
            else if (Total_5711 >= 75)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.50";
                Lg5711.Text = "C+";
            }
            else if (Total_5711 >= 67.5)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.25";
                Lg5711.Text = "C";
            }
            else if (Total_5711 >= 60)
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "2.00";
                Lg5711.Text = "D";
            }
            else
            {
                Total5711.Text = Total_5711.ToString();
                Gp5711.Text = "0.00";
                Lg5711.Text = "F";
            }
            Tc6821.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc5711.Focus();
        }

    }
    protected void Tc6821_TextChanged(object sender, EventArgs e)
    {
        int Total_6821;
        int tctxt = Convert.ToInt32(Tc6821.Text);
        int tftxt = Convert.ToInt32(Tf6821.Text);
        int pctxt = Convert.ToInt32(Pc6821.Text);
        int pftxt = Convert.ToInt32(Pf6821.Text);
        int tc_tf = (tctxt + tftxt);


        if (tctxt >= 0 && tctxt <= 30)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_6821 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_6821 = 0;
            }

            //-----6821--------//

            if (Total_6821 >= 160)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "4.00";
                Lg6821.Text = "A+";
            }
            else if (Total_6821 >= 150)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.75";
                Lg6821.Text = "A";
            }
            else if (Total_6821 >= 140)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.50";
                Lg6821.Text = "A-";
            }
            else if (Total_6821 >= 130)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.25";
                Lg6821.Text = "B+";
            }
            else if (Total_6821 >= 120)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.00";
                Lg6821.Text = "B";
            }
            else if (Total_6821 >= 110)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.75";
                Lg6821.Text = "B-";
            }
            else if (Total_6821 >= 100)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.50";
                Lg6821.Text = "C+";
            }
            else if (Total_6821 >= 90)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.25";
                Lg6821.Text = "C";
            }
            else if (Total_6821 >= 80)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.00";
                Lg6821.Text = "D";
            }
            else
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "0.00";
                Lg6821.Text = "F";
            }
            Tf6821.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=30 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tc6821.Focus();
        }

    }
    protected void Tf6821_TextChanged(object sender, EventArgs e)
    {
        int Total_6821;
        int tctxt = Convert.ToInt32(Tc6821.Text);
        int tftxt = Convert.ToInt32(Tf6821.Text);
        int pctxt = Convert.ToInt32(Pc6821.Text);
        int pftxt = Convert.ToInt32(Pf6821.Text);
        int tc_tf = (tctxt + tftxt);



        if (tftxt >= 0 && tftxt <= 120)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_6821 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_6821 = 0;
            }

            //-----6821--------//

            if (Total_6821 >= 160)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "4.00";
                Lg6821.Text = "A+";
            }
            else if (Total_6821 >= 150)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.75";
                Lg6821.Text = "A";
            }
            else if (Total_6821 >= 140)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.50";
                Lg6821.Text = "A-";
            }
            else if (Total_6821 >= 130)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.25";
                Lg6821.Text = "B+";
            }
            else if (Total_6821 >= 120)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.00";
                Lg6821.Text = "B";
            }
            else if (Total_6821 >= 110)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.75";
                Lg6821.Text = "B-";
            }
            else if (Total_6821 >= 100)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.50";
                Lg6821.Text = "C+";
            }
            else if (Total_6821 >= 90)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.25";
                Lg6821.Text = "C";
            }
            else if (Total_6821 >= 80)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.00";
                Lg6821.Text = "D";
            }
            else
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "0.00";
                Lg6821.Text = "F";
            }
            Pc6821.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=120 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Tf6821.Focus();
        }
    }
    protected void Pc6821_TextChanged(object sender, EventArgs e)
    {
        int Total_6821;
        int tctxt = Convert.ToInt32(Tc6821.Text);
        int tftxt = Convert.ToInt32(Tf6821.Text);
        int pctxt = Convert.ToInt32(Pc6821.Text);
        int pftxt = Convert.ToInt32(Pf6821.Text);
        int tc_tf = (tctxt + tftxt);

        if (pctxt >= 0 && pctxt <= 25)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_6821 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_6821 = 0;
            }

            //-----6821--------//

            if (Total_6821 >= 160)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "4.00";
                Lg6821.Text = "A+";
            }
            else if (Total_6821 >= 150)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.75";
                Lg6821.Text = "A";
            }
            else if (Total_6821 >= 140)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.50";
                Lg6821.Text = "A-";
            }
            else if (Total_6821 >= 130)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.25";
                Lg6821.Text = "B+";
            }
            else if (Total_6821 >= 120)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.00";
                Lg6821.Text = "B";
            }
            else if (Total_6821 >= 110)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.75";
                Lg6821.Text = "B-";
            }
            else if (Total_6821 >= 100)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.50";
                Lg6821.Text = "C+";
            }
            else if (Total_6821 >= 90)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.25";
                Lg6821.Text = "C";
            }
            else if (Total_6821 >= 80)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.00";
                Lg6821.Text = "D";
            }
            else
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "0.00";
                Lg6821.Text = "F";
            }
            Pf6821.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc6821.Focus();
        }
    }
    protected void Pf6821_TextChanged(object sender, EventArgs e)
    {
        int Total_6821;
        int tctxt = Convert.ToInt32(Tc6821.Text);
        int tftxt = Convert.ToInt32(Tf6821.Text);
        int pctxt = Convert.ToInt32(Pc6821.Text);
        int pftxt = Convert.ToInt32(Pf6821.Text);
        int tc_tf = (tctxt + tftxt);


        if (pftxt >= 0 && pftxt <= 25)
        {

            if (tc_tf >= 60 && pctxt >= 10 && pftxt >= 10)
            {
                Total_6821 = (tc_tf + pctxt + pftxt);
            }
            else
            {
                Total_6821 = 0;
            }

            //-----6821--------//

            if (Total_6821 >= 160)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "4.00";
                Lg6821.Text = "A+";
            }
            else if (Total_6821 >= 150)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.75";
                Lg6821.Text = "A";
            }
            else if (Total_6821 >= 140)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.50";
                Lg6821.Text = "A-";
            }
            else if (Total_6821 >= 130)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.25";
                Lg6821.Text = "B+";
            }
            else if (Total_6821 >= 120)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "3.00";
                Lg6821.Text = "B";
            }
            else if (Total_6821 >= 110)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.75";
                Lg6821.Text = "B-";
            }
            else if (Total_6821 >= 100)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.50";
                Lg6821.Text = "C+";
            }
            else if (Total_6821 >= 90)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.25";
                Lg6821.Text = "C";
            }
            else if (Total_6821 >= 80)
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "2.00";
                Lg6821.Text = "D";
            }
            else
            {
                Total6821.Text = Total_6821.ToString();
                Gp6821.Text = "0.00";
                Lg6821.Text = "F";
            }
            Pc7011.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=25 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf6821.Focus();
        }
    }
    protected void Pc7011_TextChanged(object sender, EventArgs e)
    {
        int Total_7011;
        int pctxt = Convert.ToInt32(Pc7011.Text);
        int pftxt = Convert.ToInt32(Pf7011.Text);


        if (pctxt >= 0 && pctxt <= 50)
        {

            if (pctxt >= 20 && pftxt >= 20)
            {
                Total_7011 = (pctxt + pftxt);
            }
            else
            {
                Total_7011 = 0;
            }

            //-----7011--------//

            if (Total_7011 >= 80)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "4.00";
                Lg7011.Text = "A+";
            }
            else if (Total_7011 >= 75)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.75";
                Lg7011.Text = "A";
            }
            else if (Total_7011 >= 70)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.50";
                Lg7011.Text = "A-";
            }
            else if (Total_7011 >= 65)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.25";
                Lg7011.Text = "B+";
            }
            else if (Total_7011 >= 60)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.00";
                Lg7011.Text = "B";
            }
            else if (Total_7011 >= 55)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.75";
                Lg7011.Text = "B-";
            }
            else if (Total_7011 >= 50)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.50";
                Lg7011.Text = "C+";
            }
            else if (Total_7011 >= 45)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.25";
                Lg7011.Text = "C";
            }
            else if (Total_7011 >= 40)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.00";
                Lg7011.Text = "D";
            }
            else
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "0.00";
                Lg7011.Text = "F";
            }
            Pf7011.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pc7011.Focus();
        }
    }
    protected void Pf7011_TextChanged(object sender, EventArgs e)
    {
        int Total_7011;
        int pctxt = Convert.ToInt32(Pc7011.Text);
        int pftxt = Convert.ToInt32(Pf7011.Text);

        if (pftxt >= 0 && pftxt <= 50)
        {

            if (pctxt >= 20 && pftxt >= 20)
            {
                Total_7011 = (pctxt + pftxt);
            }
            else
            {
                Total_7011 = 0;
            }

            //-----7011--------//

            if (Total_7011 >= 80)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "4.00";
                Lg7011.Text = "A+";
            }
            else if (Total_7011 >= 75)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.75";
                Lg7011.Text = "A";
            }
            else if (Total_7011 >= 70)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.50";
                Lg7011.Text = "A-";
            }
            else if (Total_7011 >= 65)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.25";
                Lg7011.Text = "B+";
            }
            else if (Total_7011 >= 60)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "3.00";
                Lg7011.Text = "B";
            }
            else if (Total_7011 >= 55)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.75";
                Lg7011.Text = "B-";
            }
            else if (Total_7011 >= 50)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.50";
                Lg7011.Text = "C+";
            }
            else if (Total_7011 >= 45)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.25";
                Lg7011.Text = "C";
            }
            else if (Total_7011 >= 40)
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "2.00";
                Lg7011.Text = "D";
            }
            else
            {
                Total7011.Text = Total_7011.ToString();
                Gp7011.Text = "0.00";
                Lg7011.Text = "F";
            }
            Btnsave.Focus();
            lblmessage.Text = "";
        }
        else
        {
            lblmessage.Text = "Required Number <=50 !";
            lblmessage.ForeColor = System.Drawing.Color.Red;
            Pf7011.Focus();
        }

    }
}
