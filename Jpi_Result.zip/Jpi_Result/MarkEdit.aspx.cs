﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class MarkEdit : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString);
    private void Connection()
    {
        if (cn.State == ConnectionState.Open)
        {
            cn.Close();
        }

        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"].ToString() == "")
        {
            Server.Transfer("Default.aspx");
        }
        Session["id"] = "";
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
        int err = 0;
       
        if (txtRoll.Text == "")
        {
            err++;
            lblmessage.Text = "Roll Number Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
        }
        else if (ddldept.SelectedValue == "Select One")
        {
            err++;
            lblmessage.Text = "Department Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
        }
        else if (ddlsemester.SelectedValue == "Select One")
        {
            err++;
            lblmessage.Text = "Semester Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
        }
        if (err == 0)
        {
            //------------------------Computer-------------------//

            if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "2nd")
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "select * from Cmt2nd where roll = @r";
                cmd.Parameters.AddWithValue("@r", txtRoll.Text);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["id"] = dr["roll"].ToString();
                    Server.Transfer("Cmt2ndEdit.aspx");
                }
                lblmessage.Text = "Database Not Found The Roll Number!";
                lblmessage.ForeColor = System.Drawing.Color.Red;

            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Civil-------------------//

           else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "2nd")
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "select * from Ct2nd where roll = @r";
                cmd.Parameters.AddWithValue("@r", txtRoll.Text);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["id"] = dr["roll"].ToString();
                    Server.Transfer("Ct2ndEdit.aspx");
                }
                lblmessage.Text = "Database Not Found The Roll Number!";
                lblmessage.ForeColor = System.Drawing.Color.Red;

            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Electrical-------------------//

           else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "2nd")
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "select * from Et2nd where roll = @r";
                cmd.Parameters.AddWithValue("@r", txtRoll.Text);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["id"] = dr["roll"].ToString();
                    Server.Transfer("Et2ndEdit.aspx");
                }
                lblmessage.Text = "Database Not Found The Roll Number!";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Electronic-------------------//

           else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "2nd")
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "select * from Ent2nd where roll = @r";
                cmd.Parameters.AddWithValue("@r", txtRoll.Text);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["id"] = dr["roll"].ToString();
                    Server.Transfer("Ent2ndEdit.aspx");
                }
                lblmessage.Text = "Database Not Found The Roll Number!";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Mechanical-------------------//

           else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "2nd")
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "select * from Mt2nd where roll = @r";
                cmd.Parameters.AddWithValue("@r", txtRoll.Text);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["id"] = dr["roll"].ToString();
                    Server.Transfer("Mt2ndEdit.aspx");
                }
                lblmessage.Text = "Database Not Found The Roll Number!";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Power-------------------//

           else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "2nd")
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "select * from Pt2nd where roll = @r";
                cmd.Parameters.AddWithValue("@r", txtRoll.Text);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["id"] = dr["roll"].ToString();
                    Server.Transfer("Pt2ndEdit.aspx");
                }
                lblmessage.Text = "Database Not Found The Roll Number!";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Telecommunication-------------------//

            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "2nd")
            {
                Connection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "select * from Tct2nd where roll = @r";
                cmd.Parameters.AddWithValue("@r", txtRoll.Text);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["id"] = dr["roll"].ToString();
                    Server.Transfer("Tct2ndEdit.aspx");
                }
                lblmessage.Text = "Database Not Found The Roll Number!";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lblmessage.Text = "Information Not Match";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
    protected void Btnreset_Click(object sender, EventArgs e)
    {
        ddldept.SelectedIndex = 0;
        ddlsemester.SelectedIndex = 0;
        txtRoll.Text = "";
        txtRoll.Focus();
        lblmessage.Text = "";
    }
}
