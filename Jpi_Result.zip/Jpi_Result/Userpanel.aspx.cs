﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class Userpanel : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString);
    private void Connection()
    {
        if (cn.State == ConnectionState.Open)
        {
            cn.Close();
        }

        cn.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"].ToString() == "")
        {
            Server.Transfer("Default.aspx");
        }
        if (Session["type"].ToString() == "A")
        {
            Server.Transfer("Default.aspx");
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        LinkButton1.Visible = false;
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
        int err = 0;
        lblmessage.Text = "";
        if (txtuname.Text == "")
        {
            err++;
            lblmessage.Text = "Username Required";
        }
        else if (txtpassword.Text == "")
        {
            err++;
            lblmessage.Text = "Password Required";
        }
        if (err == 0)
        {
            Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = @"insert into Admin (uname,pword,type) values(@uname,@pword,@type)";
            cmd.Parameters.AddWithValue("@uname", txtuname.Text);
            cmd.Parameters.AddWithValue("@pword", txtpassword.Text);
            cmd.Parameters.AddWithValue("@type", "A");
            try
            {
                cmd.ExecuteNonQuery();
                LinkButton1.Visible = true;
                Panel1.Visible = false;
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;
            }
        }
    }
}
