﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["type"].ToString() == "")
        {
            Server.Transfer("Default.aspx");
        }
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
        int err = 0;
        if (ddldept.SelectedValue == "Select One")
        {
            err++;
            lblmessage.Text = "Department Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
        }
        else if (ddlsemester.SelectedValue == "Select One")
        {
            err++;
            lblmessage.Text = "Semester Required";
            lblmessage.ForeColor = System.Drawing.Color.Red;
        }
        if (err == 0)
        {
            //------------------------Computer-------------------//

            if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue =="1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "2nd")
            {
                Server.Transfer("Cmt2nd.aspx");
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Computer" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Civil-------------------//

            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "2nd")
            {
                Server.Transfer("Ct2nd.aspx");
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Civil" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Electrical-------------------//

            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "2nd")
            {
                Server.Transfer("Et2nd.aspx");
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electrical" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Electronic-------------------//

            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "2nd")
            {
                Server.Transfer("Ent2nd.aspx");
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Electronic" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Mechanical-------------------//

            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "2nd")
            {
                Server.Transfer("Mt2nd.aspx");
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Mechanical" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Power-------------------//

            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "2nd")
            {
                Server.Transfer("Pt2nd.aspx");
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Power" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }

            //------------------------Telecommunication-------------------//

            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "1st")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "2nd")
            {
                Server.Transfer("Tct2nd.aspx");
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "3rd")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "4th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "5th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "6th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "7th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else if (ddldept.SelectedValue == "Telecommunication" && ddlsemester.SelectedValue == "8th")
            {
                lblmessage.Text = "This Page Is Not Available Now";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lblmessage.Text = "Information Not Match";
                lblmessage.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
    protected void Btnreset_Click(object sender, EventArgs e)
    {
        ddldept.SelectedIndex = 0;
        ddlsemester.SelectedIndex = 0;
        lblmessage.Text = "";
    }
}
